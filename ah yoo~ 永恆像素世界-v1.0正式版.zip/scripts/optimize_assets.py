from pathlib import Path
from PIL import Image

project = Path('/home/ubuntu/ah-yoo-eternal-pixel-world')
source = Path('/home/ubuntu/webdev-static-assets/ah-yoo-icon.png')
outputs = {
    'assets/images/icon.png': 512,
    'assets/images/splash-icon.png': 512,
    'assets/images/android-icon-foreground.png': 512,
    'assets/images/favicon.png': 192,
}

with Image.open(source) as image:
    image = image.convert('RGBA')
    for relative_path, size in outputs.items():
        target = project / relative_path
        target.parent.mkdir(parents=True, exist_ok=True)
        resized = image.resize((size, size), Image.Resampling.LANCZOS)
        resized.save(target, format='PNG', optimize=True, compress_level=9)

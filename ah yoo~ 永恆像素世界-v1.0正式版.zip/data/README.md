# 遊戲資料後台目錄

本遊戲的內容資料採資料驅動設計。`client/src/game/` 存放可重用的系統邏輯與型別，`data/` 存放原版內容資料，`content/` 代表玩家匯入後的本機內容，`mods/` 是玩家放置 ZIP 壓縮包的入口。新增物品、NPC、怪物、配方或地區時，優先新增資料檔，不要把數值寫死在畫面元件裡。

| 目錄 | 內容 | 常見檔案 |
|---|---|---|
| `items/` | 物品、材料、食物、種子、工具 | `items.json` |
| `npcs/` | NPC 名稱、職業、行程、喜好、對話 | `npcs.json` |
| `monsters/` | 怪物與自訂對手的戰鬥數值 | `monsters.json` |
| `skills/` | 技能名稱、消耗、威力與效果 | `skills.json` |
| `quests/` | 主線、支線、每日與探索任務 | `quests.json` |
| `locations/` | 地區、區塊、資源與天氣 | `locations.json` |
| `recipes/` | 製作配方與材料需求 | `recipes.json` |
| `achievements/` | 成就條件與獎勵 | `achievements.json` |
| `fish/` | 魚種、出現水域與稀有度 | `fish.json` |
| `plants/` | 作物、成長時間與收穫 | `plants.json` |
| `weapons/` | 武器攻擊力、耐久與稀有度 | `weapons.json` |
| `armor/` | 防具防禦力與效果 | `armor.json` |

每個外部資料檔都應可單獨驗證。缺少圖片時使用預設圖示，缺少音效時使用原版音效，JSON 格式錯誤時只跳過該檔並記錄錯誤。遊戲不會因單一擴充檔失敗而停止啟動。

`content/` 是解壓後的本機內容區；它與原版 `data/` 分開，方便停用或移除 mods，也避免覆蓋原版內容。ZIP 壓縮包必須包含根目錄 `manifest.json`，其餘內容只能放在攻略列出的資料夾。系統會拒絕 `../` 路徑穿越與未知根目錄。

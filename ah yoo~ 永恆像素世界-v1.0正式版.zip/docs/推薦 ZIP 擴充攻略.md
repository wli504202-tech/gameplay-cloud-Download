# ah yoo~ 永恆像素世界：推薦 ZIP 擴充攻略

## 先說結論

最推薦的方式是**在電腦完成資料整理後，壓縮成一份 ZIP，再放進遊戲的 `mods` 資料夾**。這比用 LANDrop 一份一份傳送檔案更不容易漏檔，也能保留內容的相對路徑。遊戲啟動時會掃描 `mods`，偵測到新的 `.zip` 後詢問是否讀取；按下「是」才會驗證與匯入，按下「否」則直接進入本機主選單。

## 第一步：在電腦建立資料夾

資料夾名稱可以使用英文字母、數字與連字號，例如 `my-world-pack`。不要把整個專案的 `data/` 資料夾直接塞進去，而是建立一個只放這份擴充內容的獨立包。根目錄一定要放 `manifest.json`。

```text
my-world-pack/
├─ manifest.json
├─ items/
│  └─ starlight-cookie.json
├─ npcs/
│  └─ aurora.json
├─ monsters/
│  └─ moon-beast.json
├─ skills/
│  └─ aurora-light.json
├─ quests/
│  └─ first-letter.json
├─ locations/
│  └─ aurora-hill.json
├─ recipes/
│  └─ star-tea.json
├─ images/
│  └─ aurora.png
└─ audio/
   └─ aurora_theme.ogg
```

沒有要使用的資料夾可以省略。最小可用 ZIP 只需要 `manifest.json` 加上一個合法的內容 JSON；圖片與音效是選配，缺少時遊戲會使用預設資產。

## 第二步：建立 manifest.json

```json
{
  "id": "my-world-pack",
  "name": "我的星光世界包",
  "version": "1.0.0",
  "author": "你的名字",
  "description": "新增自訂內容的擴充包。",
  "content": {
    "items": ["items/starlight-cookie.json"],
    "npcs": ["npcs/aurora.json"],
    "monsters": ["monsters/moon-beast.json"],
    "quests": ["quests/first-letter.json"],
    "images": ["images/aurora.png"],
    "audio": ["audio/aurora_theme.ogg"]
  }
}
```

`id` 必須是唯一識別字串，`name` 是遊戲提示中的顯示名稱，`version` 建議使用 `主版本.次版本.修訂版`，`author` 用來標示作者。`content` 是索引清單；實際讀取時，遊戲仍會驗證檔案路徑與 JSON 內容，不會因為 manifest 寫了不存在的檔案就停止。

## 第三步：壓縮成 ZIP

在電腦中對 `my-world-pack` 資料夾執行「壓縮成 ZIP」，最後檔名建議是 `my-world-pack.zip`。壓縮包打開後，第一層就應該看見 `manifest.json`；不要多包一層變成 `my-world-pack/my-world-pack/manifest.json`，否則遊戲找不到根目錄 manifest。

| 項目 | 建議 |
|---|---|
| 壓縮格式 | `.zip` |
| 根目錄 | 直接包含 `manifest.json` |
| 檔名 | 英文、數字、連字號較穩定 |
| 圖片 | PNG 或 JPG，像素圖請避免模糊縮放 |
| 音效 | OGG 或 WAV，使用固定且清楚的檔名 |
| JSON 編碼 | UTF-8 |

## 第四步：傳入手機

使用 USB、LANDrop 或 Android 檔案管理器，把 `.zip` 放入遊戲資料目錄的 `mods/`。若 Android 版本或檔案權限不便直接瀏覽遊戲資料夾，也可以從遊戲內的「mods 擴充中心」按「選擇 ZIP 並讀取」，使用系統檔案選擇器挑選 ZIP；遊戲會把它複製到自己的本機 `mods/` 並解壓到本機內容區。

## 第五步：重新啟動並讀取

重新啟動遊戲後，若掃描到新的 ZIP，畫面會顯示「檢測到 [檔案名.zip]，是否讀取？」。按「是」後系統會顯示約 45 秒至 1 分鐘的處理提示，依序完成解壓、manifest 驗證、JSON 驗證、圖片與音效整理。成功後內容會出現在適合的遊戲系統中；按「否」則直接進入主選單，不會刪除原本的 ZIP。

## 安全與錯誤處理

遊戲會拒絕 `../`、絕對路徑與未知根目錄，避免擴充包把內容寫到不正確位置。單一 JSON 解析失敗只會跳過該項內容，缺少圖片會使用預設圖片，缺少音效會使用原版音效，整份 ZIP 的 manifest 失敗才會跳過整包。原版 `data/` 不會被覆蓋，匯入內容會放在本機 `content/`，方便日後停用或移除。

## 建議的測試順序

先只放一份有 `manifest.json` 與一個物品 JSON 的最小 ZIP，確認遊戲可以偵測、讀取與回到主選單。接著再加入 NPC、任務、圖片與音效。每增加一種類型就重新啟動並測試一次，比一次加入大量內容更容易找到格式問題。

## 常見問題

**遊戲沒有偵測 ZIP：** 請確認副檔名是小寫 `.zip`，檔案放在 `mods/`，而不是 `content/`；也可以從遊戲內「mods 擴充中心」直接選檔。

**讀取後沒有出現內容：** 請檢查 `manifest.json` 是否位於 ZIP 根目錄，以及 `content` 內的路徑是否和檔名完全一致。

**遊戲跳過某個 JSON：** 請用 UTF-8 儲存檔案、檢查逗號與引號，並先參考專案 `examples/my-world-pack/` 的範例。

**可以不用 ZIP 嗎：** 開發時可以直接在專案的 `data/` 目錄新增檔案，但對 Android 使用者來說，ZIP 能保留完整資料夾結構，是更簡單也更可靠的分享方式。

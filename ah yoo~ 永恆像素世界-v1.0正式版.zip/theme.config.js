/** @type {const} */
const themeColors = {
  primary: { light: '#6F2DBD', dark: '#A967E7' },
  background: { light: '#F7F3FF', dark: '#120B2E' },
  surface: { light: '#FFFFFF', dark: '#1E153B' },
  foreground: { light: '#21143D', dark: '#FFF8FF' },
  muted: { light: '#6D5E89', dark: '#B9ABD9' },
  border: { light: '#D8C8EE', dark: '#503A78' },
  success: { light: '#2B8451', dark: '#65D68A' },
  warning: { light: '#B87900', dark: '#FFD166' },
  error: { light: '#B52D53', dark: '#FF5C7A' },
};

module.exports = { themeColors };

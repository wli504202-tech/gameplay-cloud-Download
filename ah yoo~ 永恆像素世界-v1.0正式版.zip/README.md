# ah yoo~ 永恆像素世界

## v1.0 正式版核心建置

這是一個以 Expo SDK 54、React Native、TypeScript 與 AsyncStorage 建立的 Android 離線單機 2D 像素開放世界 RPG 核心版本。它不需要登入、帳號、遊戲伺服器或線上資料庫；玩家可以在裝置上建立五個本機存檔，重新開啟後繼續冒險。

目前主流程包含五秒歡迎畫面、主選單、建立與載入存檔、離線收益、玩家移動、星落小鎮／低語森林／月河／銅星礦坑／日光農田的地區旅行、情境採集、挖礦、釣魚、農業、製作、背包、商店、戰鬥數值、技能、任務、圖鑑、成就、設定、Android 返回鍵與白色退出動畫。每個核心按鈕都有實際狀態轉換，不使用「Coming Soon」作為假功能。

## 目錄結構

```text
app/                         ← Expo Router 畫面入口
  (tabs)/index.tsx            ← 遊戲主選單、世界與面板 UI
client/src/game/              ← 與 UI 分離的遊戲邏輯
  types.ts                    ← 資料模型與存檔模型
  content.ts                  ← 原版資料驅動內容
  gameLogic.ts                ← 採集、戰鬥、製作、經濟與旅行
  saveSystem.ts               ← 五欄位安全存檔、備份與復原
  modSystem.ts                ← ZIP 選擇、解壓、驗證與本機匯入
data/                         ← 開發者維護的原版資料分類
content/                      ← 玩家 mods 解壓後的本機內容區
mods/                         ← 建議放置 ZIP 的入口目錄
examples/my-world-pack/       ← 可複製的 ZIP 擴充包範例
docs/                         ← ZIP 攻略、角色教學、音效說明與驗證紀錄
assets/images/                ← 歡迎、感謝、App 圖示與 Expo 資產
tests/                        ← 不依賴裝置的純邏輯單元測試
```

## ZIP mods

最推薦在電腦建立 `manifest.json`、`items/`、`npcs/`、`monsters/`、`skills/`、`quests/`、`locations/`、`recipes/`、`images/` 與 `audio/` 等資料夾，完成後壓縮成一份 ZIP，再以 USB 或 LANDrop 放入 `mods/`。重新啟動遊戲後會提示是否讀取；確認後會解壓、驗證並匯入正確的本機資料區。完整格式請閱讀 [`docs/推薦 ZIP 擴充攻略.md`](docs/推薦%20ZIP%20擴充攻略.md)。

## 開發與驗證

```bash
pnpm check
pnpm test -- --run
pnpm lint
```

Android 預覽可使用 Expo QR Code 開啟。若要產生 APK，請先在管理介面建立 checkpoint，再使用介面中的 Publish 流程；不要在沙盒中手動執行高負載 APK 建置。

## 設計決策

遊戲世界採橫向遊玩，因為橫向畫面能保留更寬的探索視野與觸控區域；啟動畫面、選單、設定與文件面板則使用可縮放的卡片配置。玩家資料只寫入 AsyncStorage，存檔流程先寫入暫存資料、解析驗證，再替換正式資料並保留上一個有效備份。原版資料與玩家匯入資料分離，避免 mods 直接破壞原版內容。

import { describe, expect, it } from "vitest";
import { DEFAULT_STATE } from "../client/src/game/content";
import { battle, craft, gather, travel } from "../client/src/game/gameLogic";

describe("Eternal Pixel World game systems", () => {
  it("gathers a real item and grants experience", () => {
    const result = gather(DEFAULT_STATE(1), "wood");
    expect(result.state.player.inventory.wood).toBe(1);
    expect(result.state.player.exp).toBe(12);
  });

  it("crafts an item only when the recipe materials exist", () => {
    const state = DEFAULT_STATE(1);
    state.player.inventory.wood = 5;
    state.player.inventory.ore = 1;
    const result = craft(state, "wood-sword");
    expect(result.state.player.inventory["wooden-sword"]).toBe(1);
    expect(result.state.player.inventory.wood).toBe(0);
    expect(result.state.player.inventory.ore).toBe(0);
  });

  it("resolves battle actions with numeric damage and rewards", () => {
    const result = battle(DEFAULT_STATE(1), "attack");
    expect(result.message).toMatch(/造成|成就解鎖/);
    const victory = battle(DEFAULT_STATE(1), "skill");
    expect(victory.state.player.gold).toBe(130);
    expect(victory.state.player.inventory.ore ?? 0).toBe(0);
    expect(victory.state.player.hp).toBe(51);
  });

  it("discovers a new location and advances the world clock", () => {
    const state = DEFAULT_STATE(1);
    const result = travel(state, "moonriver");
    expect(result.state.world.activeLocationId).toBe("moonriver");
    expect(result.state.player.discovered).toContain("moonriver");
    expect(result.state.world.timeMinutes).toBe(600);
  });
});

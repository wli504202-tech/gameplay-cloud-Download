import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Alert,
  Animated,
  BackHandler,
  Image,
  PanResponder,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
  type GestureResponderHandlers,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { ACHIEVEMENTS, FISH, ITEMS, LOCATIONS, QUESTS, RECIPES, formatTime, getItem, getLocation } from "@/client/src/game/content";
import { battle, buy, craft, fish, gather, joinGuild, mine, plantOrHarvest, sell, talkToNpc, travel, consumeItem } from "@/client/src/game/gameLogic";
import { createFreshSave, deleteSave, listSaveSlots, readSave, setLastActiveSlot, writeSave } from "@/client/src/game/saveSystem";
import { importModZip } from "@/client/src/game/modSystem";
import type { GameState, SaveSlotSummary } from "@/client/src/game/types";

const welcomeImage = require("../../assets/images/歡迎遊玩.jpg");
const thanksImage = require("../../assets/images/感謝遊玩.jpg");

type ViewName = "menu" | "game" | "saves" | "inventory" | "tasks" | "craft" | "shop" | "battle" | "map" | "guild" | "collection" | "achievements" | "settings" | "guide" | "about" | "mods";

type Toast = { text: string; tone?: "normal" | "success" | "danger" };

const weatherLabel: Record<GameState["world"]["weather"], string> = { sunny: "晴天", cloudy: "陰天", rain: "雨天", snow: "雪天" };

function PrimaryButton({ label, onPress, icon, tone = "primary", compact = false }: { label: string; onPress: () => void; icon?: string; tone?: "primary" | "secondary" | "danger" | "ghost"; compact?: boolean }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.button, compact && styles.buttonCompact, tone === "secondary" && styles.buttonSecondary, tone === "danger" && styles.buttonDanger, tone === "ghost" && styles.buttonGhost, pressed && styles.pressed]}>
      {icon ? <Text style={styles.buttonIcon}>{icon}</Text> : null}
      <Text style={[styles.buttonText, tone === "ghost" && styles.buttonGhostText]}>{label}</Text>
    </Pressable>
  );
}

function Panel({ title, subtitle, onClose, children }: { title: string; subtitle?: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <View style={styles.overlay}>
      <View style={styles.panel}>
        <View style={styles.panelHeader}>
          <View style={{ flex: 1 }}>
            <Text style={styles.panelTitle}>{title}</Text>
            {subtitle ? <Text style={styles.panelSubtitle}>{subtitle}</Text> : null}
          </View>
          <Pressable onPress={onClose} style={styles.closeButton}><Text style={styles.closeText}>×</Text></Pressable>
        </View>
        {children}
      </View>
    </View>
  );
}

function StatPill({ label, value, icon, color }: { label: string; value: string | number; icon: string; color?: string }) {
  return <View style={styles.statPill}><Text style={{ fontSize: 16 }}>{icon}</Text><View><Text style={styles.statLabel}>{label}</Text><Text style={[styles.statValue, color ? { color } : null]}>{value}</Text></View></View>;
}

export default function HomeScreen() {
  const [view, setView] = useState<ViewName>("menu");
  const [splash, setSplash] = useState(true);
  const [thanks, setThanks] = useState(false);
  const [exitOverlay, setExitOverlay] = useState(false);
  const [game, setGame] = useState<GameState | null>(null);
  const [slots, setSlots] = useState<SaveSlotSummary[]>([]);
  const [toast, setToast] = useState<Toast | null>(null);
  const [selectedItem, setSelectedItem] = useState("berry");
  const [selectedCategory, setSelectedCategory] = useState<string>("全部");
  const [searchText, setSearchText] = useState("");
  const [modBusy, setModBusy] = useState(false);
  const [modMessage, setModMessage] = useState("尚未匯入 ZIP mods。");
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [vibrationEnabled, setVibrationEnabled] = useState(true);
  const [autoSaveEnabled, setAutoSaveEnabled] = useState(true);
  const [playerName, setPlayerName] = useState("ah yoo 冒險者");
  const fade = useRef(new Animated.Value(0)).current;

  const announce = (text: string, tone: Toast["tone"] = "normal") => {
    setToast({ text, tone });
    setTimeout(() => setToast(null), 2600);
  };

  useEffect(() => {
    const timer = setTimeout(() => setSplash(false), Platform.OS === "web" ? 650 : 5000);
    Animated.timing(fade, { toValue: 1, duration: 500, useNativeDriver: true }).start();
    return () => clearTimeout(timer);
  }, [fade]);

  useEffect(() => {
    const subscription = BackHandler.addEventListener("hardwareBackPress", () => {
      if (thanks || exitOverlay) return true;
      if (view === "game") {
        confirmExit();
        return true;
      }
      if (view !== "menu") {
        setView("menu");
        return true;
      }
      confirmExit();
      return true;
    });
    return () => subscription.remove();
  });

  useEffect(() => {
    if (autoSaveEnabled && game && view === "game") {
      const timer = setTimeout(() => {
        writeSave(game).then((saved) => setGame(saved)).catch(() => announce("自動存檔失敗，仍保留目前畫面。", "danger"));
      }, 9000);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, [autoSaveEnabled, game, view]);

  const currentLocation = getLocation(game?.world.activeLocationId ?? "starfall-town");
  const inventoryItems = useMemo(() => {
    const inventory = game?.player.inventory ?? {};
    return ITEMS.filter((item) => (inventory[item.id] ?? 0) > 0 && (selectedCategory === "全部" || item.category === selectedCategory) && item.name.includes(searchText));
  }, [game?.player.inventory, searchText, selectedCategory]);

  const applyResult = (result: { state: GameState; message: string }) => {
    setGame(result.state);
    announce(result.message, result.message.includes("完成") || result.message.includes("勝利") ? "success" : "normal");
  };

  const startGame = async (slotId = 1) => {
    const fresh = await createFreshSave(slotId);
    fresh.player.name = playerName || "ah yoo 冒險者";
    setGame(fresh);
    await setLastActiveSlot(slotId);
    setView("game");
    announce("新的星光冒險開始了。", "success");
  };

  const loadSlot = async (slotId: number) => {
    const saved = await readSave(slotId);
    if (!saved) {
      announce("這個欄位還沒有存檔。", "danger");
      return;
    }
    const last = new Date(saved.updatedAt).getTime();
    const hours = Math.min(72, Math.max(0, (Date.now() - last) / 3600000));
    if (hours >= 0.1) {
      const reward = Math.floor(hours * 4);
      saved.player.gold += reward;
      saved.world.eventMessage = `你離線了 ${hours.toFixed(1)} 小時，本次獲得離線收益：${reward} 金幣。`;
    }
    setGame(saved);
    await setLastActiveSlot(slotId);
    setView("game");
    announce(saved.world.eventMessage, "success");
  };

  const refreshSlots = async () => setSlots(await listSaveSlots());

  const openSaves = async () => { await refreshSlots(); setView("saves"); };

  const saveNow = async () => {
    if (!game) return;
    const saved = await writeSave(game);
    setGame(saved);
    announce(`已安全存檔至第 ${saved.slotId} 格。`, "success");
  };

  const confirmExit = () => {
    Alert.alert("離開永恆世界", "確定要退出遊戲嗎？", [{ text: "取消", style: "cancel" }, { text: "確定", style: "destructive", onPress: playExit }]);
  };

  const playExit = () => {
    setExitOverlay(true);
    setTimeout(() => {
      setExitOverlay(false);
      setThanks(true);
      setTimeout(() => {
        setThanks(false);
        setView("menu");
        if (Platform.OS !== "web") BackHandler.exitApp();
      }, 3000);
    }, 650);
  };

  const runAction = (fn: (state: GameState) => { state: GameState; message: string }) => {
    if (!game) return;
    applyResult(fn(game));
  };

  const joystickResponder = useMemo(() => PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderMove: (_, gesture) => {
      if (!game) return;
      const dx = Math.max(-1, Math.min(1, gesture.dx / 50));
      const dy = Math.max(-1, Math.min(1, gesture.dy / 50));
      setGame((current) => current ? { ...current, player: { ...current.player, x: current.player.x + dx, y: current.player.y + dy }, world: { ...current.world, eventMessage: `沿著星光移動（${Math.round(current.player.x + dx)}, ${Math.round(current.player.y + dy)}）` } } : current);
    },
  }), [game]);

  const showContent = (nextView: ViewName) => { if (nextView === "saves") void refreshSlots(); setView(nextView); };

  if (splash) return <View style={styles.fullScreen}><Image source={welcomeImage} style={styles.splashImage} resizeMode="cover" /><View style={styles.splashBadge}><Text style={styles.splashSmall}>AH YOO~</Text><Text style={styles.splashLoading}>星光正在連線到你的本機世界…</Text></View></View>;
  if (thanks) return <View style={styles.fullScreen}><Image source={thanksImage} style={styles.splashImage} resizeMode="cover" /></View>;

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]} containerClassName="bg-background">
      <Animated.View style={[styles.app, { opacity: fade, backgroundColor: "#120B2E" }]}>
        {view === "menu" ? (
          <ScrollView contentContainerStyle={styles.menuScroll}>
            <View style={styles.menuHero}>
              <View style={styles.logoOrb}><Text style={styles.logoStar}>✦</Text></View>
              <View><Text style={styles.brandEyebrow}>AH YOO~ PRESENTS</Text><Text style={styles.brandTitle}>永恆像素世界</Text><Text style={styles.brandSubtitle}>Eternal Pixel World · v1.0 正式版</Text></View>
            </View>
            <View style={styles.menuGrid}>
              <View style={styles.menuPrimaryColumn}>
                <PrimaryButton label="開始新的冒險" icon="✦" onPress={() => void startGame(1)} />
                <PrimaryButton label="載入本機存檔" icon="↗" tone="secondary" onPress={() => void openSaves()} />
                <View style={styles.nameCard}><Text style={styles.cardLabel}>冒險者名稱</Text><TextInput value={playerName} onChangeText={setPlayerName} style={styles.nameInput} placeholder="輸入你的名字" placeholderTextColor="#9c91c2" /></View>
              </View>
              <View style={styles.menuSecondaryColumn}>
                <PrimaryButton label="圖鑑與收藏" icon="◈" tone="ghost" compact onPress={() => showContent("collection")} />
                <PrimaryButton label="成就" icon="☆" tone="ghost" compact onPress={() => showContent("achievements")} />
                <PrimaryButton label="設定" icon="⚙" tone="ghost" compact onPress={() => showContent("settings")} />
                <PrimaryButton label="說明／ZIP 攻略" icon="?" tone="ghost" compact onPress={() => showContent("guide")} />
                <PrimaryButton label="關於遊戲" icon="i" tone="ghost" compact onPress={() => showContent("about")} />
                <PrimaryButton label="離開遊戲" icon="×" tone="danger" compact onPress={confirmExit} />
              </View>
            </View>
            <View style={styles.offlineBanner}><Text style={styles.offlineDot}>●</Text><Text style={styles.offlineText}>完全離線單機 · 不需要伺服器 · 存檔留在你的裝置</Text></View>
          </ScrollView>
        ) : view === "game" && game ? (
          <GameView game={game} location={currentLocation} onAction={runAction} onOpen={showContent} onTravel={(id) => runAction((state) => travel(state, id))} onSave={saveNow} onExit={confirmExit} onMove={joystickResponder.panHandlers} />
        ) : null}

        {view === "saves" ? <SavePanel slots={slots} onClose={() => setView("menu")} onStart={startGame} onLoad={loadSlot} onDelete={async (slotId) => { await deleteSave(slotId); await refreshSlots(); announce(`第 ${slotId} 格存檔已刪除。`); }} /> : null}
        {view === "inventory" && game ? <InventoryPanel game={game} items={inventoryItems} selectedItem={selectedItem} selectedCategory={selectedCategory} searchText={searchText} setSelectedItem={setSelectedItem} setSelectedCategory={setSelectedCategory} setSearchText={setSearchText} onUse={(id) => runAction((state) => consumeItem(state, id))} onSell={(id) => runAction((state) => sell(state, id))} onClose={() => setView("game")} /> : null}
        {view === "tasks" && game ? <TaskPanel game={game} onClose={() => setView("game")} /> : null}
        {view === "craft" && game ? <CraftPanel game={game} onCraft={(id) => runAction((state) => craft(state, id))} onClose={() => setView("game")} /> : null}
        {view === "shop" && game ? <ShopPanel game={game} onBuy={(id) => runAction((state) => buy(state, id))} onSell={(id) => runAction((state) => sell(state, id))} onClose={() => setView("game")} /> : null}
        {view === "battle" && game ? <BattlePanel game={game} onBattle={(action) => runAction((state) => battle(state, action))} onClose={() => setView("game")} /> : null}
        {view === "guild" && game ? <GuildPanel game={game} onGuild={() => runAction(joinGuild)} onClose={() => setView("game")} /> : null}
        {view === "map" && game ? <MapPanel game={game} onTravel={(id) => { runAction((state) => travel(state, id)); setView("game"); }} onClose={() => setView("game")} /> : null}
        {view === "collection" ? <CollectionPanel onClose={() => setView(game ? "game" : "menu")} game={game} /> : null}
        {view === "achievements" ? <AchievementPanel onClose={() => setView(game ? "game" : "menu")} game={game} /> : null}
        {view === "settings" ? <SettingsPanel soundEnabled={soundEnabled} vibrationEnabled={vibrationEnabled} autoSaveEnabled={autoSaveEnabled} onSound={setSoundEnabled} onVibration={setVibrationEnabled} onAutoSave={setAutoSaveEnabled} onClose={() => setView("menu")} /> : null}
        {view === "guide" ? <GuidePanel onClose={() => setView(game ? "game" : "menu")} onMods={() => setView("mods")} /> : null}
        {view === "mods" ? <ModsPanel busy={modBusy} message={modMessage} onImport={async () => { setModBusy(true); const result = await importModZip(); setModMessage(result.message); setModBusy(false); }} onClose={() => setView("menu")} /> : null}
        {view === "about" ? <AboutPanel onClose={() => setView("menu")} /> : null}
        {exitOverlay ? <View style={styles.exitMask}><Text style={styles.exitText}>正在保存永恆世界…</Text></View> : null}
        {toast ? <View style={[styles.toast, toast.tone === "success" && styles.toastSuccess, toast.tone === "danger" && styles.toastDanger]}><Text style={styles.toastText}>{toast.text}</Text></View> : null}
      </Animated.View>
    </ScreenContainer>
  );
}

function GameView({ game, location, onAction, onOpen, onTravel, onSave, onExit, onMove }: { game: GameState; location: ReturnType<typeof getLocation>; onAction: (fn: (state: GameState) => { state: GameState; message: string }) => void; onOpen: (view: ViewName) => void; onTravel: (locationId: string) => void; onSave: () => void; onExit: () => void; onMove: GestureResponderHandlers }) {
  const actionButtons = location.id === "moonriver" ? [{ label: "釣魚", icon: "◒", action: () => onAction(fish) }] : location.id === "copper-mine" ? [{ label: "挖礦", icon: "◆", action: () => onAction(mine) }] : location.id === "sunmeadow" ? [{ label: "農場", icon: "✿", action: () => onAction(plantOrHarvest) }] : location.id === "starfall-town" ? [{ label: "對話", icon: "☵", action: () => onAction((state) => talkToNpc(state, "mira")) }] : [{ label: "採集", icon: "✦", action: () => onAction(gather) }];
  return <View style={styles.gameRoot}>
    <View style={styles.hudTop}><View><Text style={styles.hudEyebrow}>永恆世界 · {weatherLabel[game.world.weather]}</Text><Text style={styles.hudLocation}>{location.name}</Text></View><View style={styles.hudStats}><StatPill label="等級" value={game.player.level} icon="✦" color="#FFD166" /><StatPill label="金幣" value={game.player.gold} icon="◈" color="#FFD166" /><StatPill label="時間" value={formatTime(game.world.timeMinutes)} icon="◷" /></View><Pressable onPress={onExit} style={styles.hudExit}><Text style={styles.hudExitText}>×</Text></Pressable></View>
    <View style={[styles.worldCanvas, { backgroundColor: location.color }]}><View style={styles.pixelSun}><Text>✦</Text></View><View style={styles.worldGlow} /><View style={styles.worldLabel}><Text style={styles.worldLabelTitle}>{location.name}</Text><Text style={styles.worldLabelSubtitle}>{location.subtitle}</Text></View><View style={[styles.playerSprite, { left: `${45 + Math.max(-8, Math.min(8, game.player.x))}%`, top: `${42 + Math.max(-8, Math.min(8, game.player.y))}%` }]}><Text style={styles.playerEmoji}>🧙</Text><Text style={styles.playerName}>{game.player.name}</Text></View><View style={[styles.resource, styles.resourceA]}><Text>✦</Text></View><View style={[styles.resource, styles.resourceB]}><Text>♣</Text></View><View style={styles.worldHint}><Text style={styles.worldHintText}>{game.world.eventMessage}</Text></View></View>
    <View style={styles.controlLayer}><View {...onMove} style={styles.joystick}><View style={styles.joystickRing}><View style={styles.joystickKnob}><Text style={styles.joystickText}>✧</Text></View></View><Text style={styles.controlCaption}>拖曳移動</Text></View><View style={styles.actionCluster}>{actionButtons.map((item) => <Pressable key={item.label} onPress={item.action} style={({ pressed }) => [styles.actionButton, pressed && styles.pressed]}><Text style={styles.actionIcon}>{item.icon}</Text><Text style={styles.actionText}>{item.label}</Text></Pressable>)}<Pressable onPress={() => onOpen("battle")} style={styles.actionButton}><Text style={styles.actionIcon}>⚔</Text><Text style={styles.actionText}>戰鬥</Text></Pressable><Pressable onPress={() => onOpen("shop")} style={styles.actionButton}><Text style={styles.actionIcon}>♜</Text><Text style={styles.actionText}>商店</Text></Pressable></View></View>
    <View style={styles.gameNav}><PrimaryButton label="背包" icon="▦" tone="ghost" compact onPress={() => onOpen("inventory")} /><PrimaryButton label="任務" icon="✓" tone="ghost" compact onPress={() => onOpen("tasks")} /><PrimaryButton label="製作" icon="⌘" tone="ghost" compact onPress={() => onOpen("craft")} /><PrimaryButton label="地圖" icon="⌖" tone="ghost" compact onPress={() => onOpen("map")} /><PrimaryButton label="圖鑑" icon="◈" tone="ghost" compact onPress={() => onOpen("collection")} /><PrimaryButton label="公會" icon="♛" tone="ghost" compact onPress={() => onOpen("guild")} /><PrimaryButton label="立即存檔" icon="↓" tone="secondary" compact onPress={onSave} /></View>
  </View>;
}

function SavePanel({ slots, onClose, onStart, onLoad, onDelete }: { slots: SaveSlotSummary[]; onClose: () => void; onStart: (slotId: number) => void; onLoad: (slotId: number) => void; onDelete: (slotId: number) => void }) {
  return <Panel title="本機存檔" subtitle="五個欄位 · 安全備份 · 不需要網路" onClose={onClose}><ScrollView><Text style={styles.panelIntro}>存檔會先寫入暫存檔並驗證，成功後才替換正式檔，同時保留上一個有效版本。</Text>{[1, 2, 3, 4, 5].map((slotId) => { const slot = slots.find((item) => item.slotId === slotId); return <View style={styles.saveRow} key={slotId}><View style={styles.saveSlotBadge}><Text style={styles.saveSlotText}>{slotId}</Text></View><View style={{ flex: 1 }}><Text style={styles.saveTitle}>{slot?.exists ? `星光旅程 · ${slot.locationName}` : "空白存檔欄位"}</Text><Text style={styles.saveMeta}>{slot?.exists ? `Lv.${slot.level} · ${slot.gold} 金幣 · ${new Date(slot.updatedAt ?? "").toLocaleString()}` : "可以開始一段新的冒險"}</Text></View><View style={styles.rowActions}>{slot?.exists ? <><PrimaryButton label="載入" compact onPress={() => void onLoad(slotId)} /><PrimaryButton label="刪除" compact tone="danger" onPress={() => Alert.alert("刪除存檔", `確定刪除第 ${slotId} 格？`, [{ text: "取消", style: "cancel" }, { text: "刪除", style: "destructive", onPress: () => void onDelete(slotId) }])} /></> : <PrimaryButton label="建立" compact onPress={() => void onStart(slotId)} />}</View></View>; })}</ScrollView></Panel>;
}

function InventoryPanel({ game, items, selectedItem, selectedCategory, searchText, setSelectedItem, setSelectedCategory, setSearchText, onUse, onSell, onClose }: { game: GameState; items: typeof ITEMS; selectedItem: string; selectedCategory: string; searchText: string; setSelectedItem: (value: string) => void; setSelectedCategory: (value: string) => void; setSearchText: (value: string) => void; onUse: (id: string) => void; onSell: (id: string) => void; onClose: () => void }) {
  const item = getItem(selectedItem) ?? items[0];
  return <Panel title="背包" subtitle={`${Object.values(game.player.inventory).reduce((sum, n) => sum + n, 0)} / 40 格 · 點擊物品查看操作`} onClose={onClose}><View style={styles.searchRow}><TextInput value={searchText} onChangeText={setSearchText} placeholder="搜尋物品" placeholderTextColor="#9589b3" style={styles.searchInput} />{["全部", "material", "food", "fish", "seed", "equipment"].map((category) => <Pressable key={category} onPress={() => setSelectedCategory(category)} style={[styles.filterChip, selectedCategory === category && styles.filterChipActive]}><Text style={styles.filterText}>{category === "全部" ? "全部" : category}</Text></Pressable>)}</View><ScrollView contentContainerStyle={styles.itemGrid}>{items.map((entry) => <Pressable key={entry.id} onPress={() => setSelectedItem(entry.id)} style={[styles.itemCard, selectedItem === entry.id && styles.itemCardActive]}><Text style={styles.itemIcon}>{entry.icon}</Text><Text style={styles.itemName}>{entry.name}</Text><Text style={styles.itemCount}>×{game.player.inventory[entry.id] ?? 0}</Text></Pressable>)}</ScrollView>{item ? <View style={styles.detailCard}><View style={styles.detailIcon}><Text style={{ fontSize: 32 }}>{item.icon}</Text></View><View style={{ flex: 1 }}><Text style={styles.detailTitle}>{item.name}</Text><Text style={styles.detailDescription}>{item.description}</Text><Text style={styles.detailMeta}>稀有度：{item.rarity} · 售價：{item.value} 金幣</Text></View><PrimaryButton label="使用" compact onPress={() => onUse(item.id)} /><PrimaryButton label="出售" compact tone="secondary" onPress={() => onSell(item.id)} /></View> : null}</Panel>;
}

function TaskPanel({ game, onClose }: { game: GameState; onClose: () => void }) { return <Panel title="任務手冊" subtitle="任務是邀請，不是唯一的道路" onClose={onClose}><ScrollView>{QUESTS.map((quest) => { const completed = game.player.completedQuests.includes(quest.id); return <View key={quest.id} style={styles.listCard}><View style={[styles.questIcon, completed && styles.questDone]}><Text>{completed ? "✓" : "✦"}</Text></View><View style={{ flex: 1 }}><Text style={styles.listTitle}>{quest.title}</Text><Text style={styles.listDescription}>{quest.description}</Text><Text style={styles.listMeta}>獎勵：{quest.rewardGold} 金幣 · {quest.rewardExp} EXP</Text></View><Text style={[styles.statusText, completed && styles.statusDone]}>{completed ? "已完成" : "探索中"}</Text></View>; })}</ScrollView></Panel>; }

function CraftPanel({ game, onCraft, onClose }: { game: GameState; onCraft: (id: string) => void; onClose: () => void }) { return <Panel title="星火製作台" subtitle="配方由資料檔管理，可以用 mods 擴充" onClose={onClose}><ScrollView>{RECIPES.map((recipe) => { const output = getItem(recipe.outputItemId); const canCraft = Object.entries(recipe.ingredients).every(([id, count]) => (game.player.inventory[id] ?? 0) >= count); return <View key={recipe.id} style={styles.listCard}><Text style={styles.recipeIcon}>{output?.icon ?? "✦"}</Text><View style={{ flex: 1 }}><Text style={styles.listTitle}>{recipe.name}</Text><Text style={styles.listDescription}>{Object.entries(recipe.ingredients).map(([id, count]) => `${getItem(id)?.name ?? id} ×${count}`).join("  ·  ")}</Text></View><PrimaryButton label={canCraft ? "製作" : "缺材料"} compact tone={canCraft ? "primary" : "ghost"} onPress={() => onCraft(recipe.id)} /></View>; })}</ScrollView></Panel>; }

function ShopPanel({ game, onBuy, onSell, onClose }: { game: GameState; onBuy: (id: string) => void; onSell: (id: string) => void; onClose: () => void }) { const shopItems = ITEMS.filter((item) => ["seed", "food", "equipment", "material"].includes(item.category)).slice(0, 8); return <Panel title="米拉的星落商店" subtitle={`金幣 ${game.player.gold} · 價格會隨地區與稀有度變化`} onClose={onClose}><ScrollView>{shopItems.map((item) => <View key={item.id} style={styles.listCard}><Text style={styles.recipeIcon}>{item.icon}</Text><View style={{ flex: 1 }}><Text style={styles.listTitle}>{item.name}</Text><Text style={styles.listDescription}>{item.description}</Text><Text style={styles.listMeta}>買入約 {Math.round(item.value * 1.6)} 金幣 · 賣出 {item.value} 金幣</Text></View><PrimaryButton label="買入" compact onPress={() => onBuy(item.id)} /><PrimaryButton label="賣出" compact tone="secondary" onPress={() => onSell(item.id)} /></View>)}</ScrollView></Panel>; }

function BattlePanel({ game, onBattle, onClose }: { game: GameState; onBattle: (action: "attack" | "skill" | "guard" | "item") => void; onClose: () => void }) { return <Panel title="戰鬥：星塵史萊姆" subtitle="所有數值都會實際結算，勝利會取得經驗與掉落" onClose={onClose}><View style={styles.battleArena}><View style={styles.battleUnit}><Text style={styles.battleEmoji}>🧙</Text><Text style={styles.battleName}>{game.player.name}</Text><Text style={styles.hpText}>HP {game.player.hp} / {game.player.maxHp}</Text><View style={styles.hpBar}><View style={[styles.hpFill, { width: `${Math.max(4, game.player.hp / game.player.maxHp * 100)}%` }]} /></View></View><Text style={styles.battleVs}>VS</Text><View style={styles.battleUnit}><Text style={styles.battleEmoji}>🟣</Text><Text style={styles.battleName}>星塵史萊姆</Text><Text style={styles.hpText}>HP 28 / 28</Text><View style={styles.hpBar}><View style={[styles.hpFill, styles.enemyHp, { width: "100%" }]} /></View></View></View><View style={styles.battleActions}><PrimaryButton label="攻擊" icon="⚔" onPress={() => onBattle("attack")} /><PrimaryButton label="星閃斬" icon="✦" onPress={() => onBattle("skill")} /><PrimaryButton label="防禦" icon="◈" tone="secondary" onPress={() => onBattle("guard")} /><PrimaryButton label="道具" icon="🧪" tone="secondary" onPress={() => onBattle("item")} /></View><Text style={styles.battleTip}>左側功能入口也提供「自己做對手」JSON 教學，放入 mods 後即可驗證並載入。</Text></Panel>; }

function GuildPanel({ game, onGuild, onClose }: { game: GameState; onGuild: () => void; onClose: () => void }) { const guild = game.player.guild; return <Panel title="星落探險公會" subtitle="單機 NPC 公會 · 任務、活動與獎勵" onClose={onClose}><View style={styles.guildHero}><Text style={styles.guildCrest}>♛</Text><View style={{ flex: 1 }}><Text style={styles.listTitle}>{guild.name}</Text><Text style={styles.listDescription}>{guild.joined ? `公會等級 Lv.${guild.level} · 聲望 ${guild.renown} / ${guild.level * 25}` : "加入後可以接受 NPC 公會任務並累積聲望。"}</Text></View><Text style={styles.statusText}>{guild.joined ? "會員" : "未加入"}</Text></View><Text style={styles.sectionHeading}>公會活動</Text><View style={styles.listCard}><Text style={styles.recipeIcon}>✦</Text><View style={{ flex: 1 }}><Text style={styles.listTitle}>{guild.joined ? "完成今日探索活動" : "加入星落探險公會"}</Text><Text style={styles.listDescription}>{guild.joined ? "完成一次活動可獲得 5 點聲望，達到門檻後公會升級。" : "加入即可領取公會歡迎禮，並解鎖 NPC 公會商店與任務。"}</Text></View><PrimaryButton label={guild.joined ? "執行活動" : "加入"} onPress={onGuild} compact /></View><Text style={styles.sectionHeading}>公會系統</Text><Text style={styles.guideText}>公會是完全離線的 NPC 系統，不需要多人連線。未來可透過 mods 新增公會任務、商店商品、活動條件與獎勵資料。</Text></Panel>; }

function MapPanel({ game, onTravel, onClose }: { game: GameState; onTravel: (locationId: string) => void; onClose: () => void }) { return <Panel title="星圖" subtitle="雙指地圖預留 · 點擊地區即可旅行" onClose={onClose}><ScrollView><Text style={styles.panelIntro}>附近區塊會按需載入。發現新地區後，該地區的 NPC、資源、事件與圖鑑會逐步展開。</Text>{LOCATIONS.map((location) => { const discovered = game.player.discovered.includes(location.id); const active = game.world.activeLocationId === location.id; return <Pressable key={location.id} onPress={() => onTravel(location.id)} style={[styles.mapCard, { backgroundColor: `${location.color}CC` }, active && styles.mapCardActive]}><View style={styles.mapPin}><Text>{active ? "◉" : discovered ? "●" : "◇"}</Text></View><View style={{ flex: 1 }}><Text style={styles.listTitle}>{location.name}</Text><Text style={styles.listDescription}>{location.subtitle} · {location.climate}</Text><Text style={styles.listMeta}>資源：{location.resources.join("、")}</Text></View><Text style={styles.statusText}>{active ? "目前" : discovered ? "已發現" : "探索"}</Text></Pressable>; })}</ScrollView></Panel>; }

function CollectionPanel({ game, onClose }: { game: GameState | null; onClose: () => void }) { const discovered = game?.player.discovered ?? []; return <Panel title="圖鑑與收藏" subtitle="發現世界、收集物品，讓未知逐一亮起" onClose={onClose}><ScrollView><Text style={styles.sectionHeading}>地區圖鑑 · {discovered.length} / {LOCATIONS.length}</Text>{LOCATIONS.map((location) => <View key={location.id} style={styles.listCard}><Text style={styles.recipeIcon}>{discovered.includes(location.id) ? "◉" : "◇"}</Text><View style={{ flex: 1 }}><Text style={styles.listTitle}>{discovered.includes(location.id) ? location.name : "尚未發現的地區"}</Text><Text style={styles.listDescription}>{discovered.includes(location.id) ? `${location.subtitle} · 資源：${location.resources.join("、")}` : "探索後解鎖地區資料"}</Text></View><Text style={styles.statusText}>{discovered.includes(location.id) ? "已發現" : "未發現"}</Text></View>)}<Text style={styles.sectionHeading}>魚類圖鑑 · {game?.player.inventory["river-fish"] ? "1" : "0"} / {FISH.length}</Text>{FISH.map((entry) => <View key={entry.id} style={styles.listCard}><Text style={styles.recipeIcon}>{game?.player.inventory[entry.id] ? "🐟" : "?"}</Text><View style={{ flex: 1 }}><Text style={styles.listTitle}>{game?.player.inventory[entry.id] ? entry.name : "神秘魚影"}</Text><Text style={styles.listDescription}>{game?.player.inventory[entry.id] ? `價值 ${entry.value} 金幣 · ${entry.rarity}` : "前往月河嘗試釣魚"}</Text></View></View>)}</ScrollView></Panel>; }

function AchievementPanel({ game, onClose }: { game: GameState | null; onClose: () => void }) { return <Panel title="成就" subtitle={`${game?.player.achievements.length ?? 0} / ${ACHIEVEMENTS.length} 已解鎖`} onClose={onClose}><ScrollView>{ACHIEVEMENTS.map((entry) => { const unlocked = game?.player.achievements.includes(entry.id); return <View key={entry.id} style={[styles.listCard, unlocked && styles.achievementUnlocked]}><Text style={styles.recipeIcon}>{unlocked ? "🏆" : "◇"}</Text><View style={{ flex: 1 }}><Text style={styles.listTitle}>{entry.title}</Text><Text style={styles.listDescription}>{entry.description}</Text><Text style={styles.listMeta}>獎勵：{entry.rewardGold} 金幣</Text></View><Text style={styles.statusText}>{unlocked ? "已解鎖" : "進行中"}</Text></View>; })}</ScrollView></Panel>; }

function SettingsPanel({ soundEnabled, vibrationEnabled, autoSaveEnabled, onSound, onVibration, onAutoSave, onClose }: { soundEnabled: boolean; vibrationEnabled: boolean; autoSaveEnabled: boolean; onSound: (value: boolean) => void; onVibration: (value: boolean) => void; onAutoSave: (value: boolean) => void; onClose: () => void }) { const [performance, setPerformance] = useState("自動"); return <Panel title="設定" subtitle="所有選項都儲存在本機" onClose={onClose}><ScrollView><View style={styles.settingRow}><View><Text style={styles.listTitle}>音樂與音效</Text><Text style={styles.listDescription}>主選單、城鎮、釣魚、戰鬥與 UI 聲音</Text></View><Switch value={soundEnabled} onValueChange={onSound} /></View><View style={styles.settingRow}><View><Text style={styles.listTitle}>震動回饋</Text><Text style={styles.listDescription}>主要按鈕與完成事件提供觸控回饋</Text></View><Switch value={vibrationEnabled} onValueChange={onVibration} /></View><View style={styles.settingRow}><View><Text style={styles.listTitle}>自動存檔</Text><Text style={styles.listDescription}>遊戲進行中定期建立安全存檔</Text></View><Switch value={autoSaveEnabled} onValueChange={onAutoSave} /></View><Text style={styles.sectionHeading}>效能模式</Text><View style={styles.performanceRow}>{["低", "中", "高", "極高", "自動"].map((value) => <Pressable key={value} onPress={() => setPerformance(value)} style={[styles.performanceChip, value === performance && styles.performanceActive]}><Text style={styles.filterText}>{value}</Text></Pressable>)}</View><Text style={styles.settingHint}>建議使用「自動」。世界會依附近區塊按需載入，不會因高畫質一次載入全部地圖與圖片。</Text></ScrollView></Panel>; }

function GuidePanel({ onClose, onMods }: { onClose: () => void; onMods: () => void }) { return <Panel title="說明與 ZIP 攻略" subtitle="清楚的後台資料夾，讓你可以持續擴充世界" onClose={onClose}><ScrollView><View style={styles.guideHero}><Text style={styles.guideHeroIcon}>▣</Text><View><Text style={styles.listTitle}>推薦：使用一份 ZIP 壓縮包</Text><Text style={styles.listDescription}>比起一份一份搬檔案，ZIP 可以保留完整結構，放入 mods 後重新啟動即可被偵測。</Text></View></View><Text style={styles.sectionHeading}>快速流程</Text><Text style={styles.guideText}>1. 在電腦建立資料夾並依攻略放入 manifest.json、JSON、圖片與音效。{"\n"}2. 將整個資料夾壓縮成 `my-world-pack.zip`。{ "\n" }3. 用 USB、LANDrop 或檔案管理器放入遊戲的 `mods` 資料夾。{ "\n" }4. 重新啟動遊戲，看到「檢測到 [檔案名.zip]」後按「讀取」。{ "\n" }5. 系統顯示約 45 秒至 1 分鐘的讀取狀態，驗證完成才啟用。</Text><Text style={styles.sectionHeading}>推薦的 ZIP 結構</Text><View style={styles.codeBlock}><Text style={styles.codeText}>my-world-pack.zip{"\n"}├─ manifest.json{"\n"}├─ items/      ← 物品 JSON{"\n"}├─ npcs/       ← NPC JSON{"\n"}├─ monsters/   ← 怪物與自訂對手{"\n"}├─ locations/  ← 地區與區塊設定{"\n"}├─ recipes/    ← 製作配方{"\n"}├─ skills/     ← 技能資料{"\n"}├─ quests/     ← 任務資料{"\n"}├─ images/     ← PNG/JPG 像素圖{"\n"}└─ audio/      ← OGG/WAV 自訂音效</Text></View><Text style={styles.sectionHeading}>安全規則</Text><Text style={styles.guideText}>每個 ZIP 必須有 manifest.json。系統會拒絕路徑穿越、跳過未知資料夾，單一 JSON 或圖片錯誤不會讓遊戲崩潰；錯誤內容會被跳過並保留原版資料。</Text><View style={styles.guideButtons}><PrimaryButton label="開啟 mods 匯入" icon="▣" onPress={onMods} /><PrimaryButton label="閱讀對戰角色教學" icon="⚔" tone="secondary" onPress={() => Alert.alert("對戰角色製作教學.txt", "請在專案的 docs/對戰角色製作教學.txt 查看完整 JSON 欄位與範例。")}/></View></ScrollView></Panel>; }

function ModsPanel({ busy, message, onImport, onClose }: { busy: boolean; message: string; onImport: () => void; onClose: () => void }) { return <Panel title="mods 擴充中心" subtitle="ZIP 優先 · 本機讀取 · 無需登入" onClose={onClose}><View style={styles.modDrop}><Text style={styles.modIcon}>▣</Text><Text style={styles.listTitle}>選擇一份 ZIP 壓縮包</Text><Text style={styles.listDescription}>從 Android 檔案選擇器挑選 `my-world-pack.zip`，系統會解壓、驗證並放到正確的本機資料夾。</Text><PrimaryButton label={busy ? "正在讀取，請稍候…" : "選擇 ZIP 並讀取"} icon="＋" onPress={onImport} /></View><View style={styles.modStatus}><Text style={styles.sectionHeading}>匯入狀態</Text><Text style={styles.guideText}>{message}</Text></View><Text style={styles.settingHint}>預設路徑：遊戲資料夾 / mods /。若無法直接存取 Android 公開資料夾，可先用檔案選擇器挑選 ZIP，遊戲會將它複製到自己的 mods 目錄。</Text></Panel>; }

function AboutPanel({ onClose }: { onClose: () => void }) { return <Panel title="關於 ah yoo~ 永恆像素世界" subtitle="v1.0 正式版" onClose={onClose}><View style={styles.aboutMark}><View style={styles.logoOrb}><Text style={styles.logoStar}>✦</Text></View><Text style={styles.brandTitle}>ah yoo~</Text><Text style={styles.aboutType}>2D Pixel Open World RPG</Text></View><Text style={styles.aboutText}>本遊戲由 ah yoo~ 製作，是一款可愛、卡通、2D 像素、手機觸控、離線單機的開放世界 RPG。你可以釣魚、挖礦、農業、探索、戰鬥、製作、經商、加入 NPC 公會、收集並尋找秘密。</Text><View style={styles.offlineBanner}><Text style={styles.offlineDot}>●</Text><Text style={styles.offlineText}>本遊戲為離線單機遊戲，不需要遊戲伺服器。</Text></View></Panel>; }

const styles = StyleSheet.create({
  fullScreen: { flex: 1, backgroundColor: "#120B2E", alignItems: "center", justifyContent: "center" },
  splashImage: { width: "100%", height: "100%" },
  splashBadge: { position: "absolute", bottom: 28, alignItems: "center", paddingHorizontal: 20, paddingVertical: 10, borderRadius: 20, backgroundColor: "rgba(18,11,46,0.74)" },
  splashSmall: { color: "#FF3FC7", fontSize: 12, fontWeight: "900", letterSpacing: 4 },
  splashLoading: { marginTop: 4, color: "#FFF8FF", fontSize: 13, fontWeight: "700" },
  app: { flex: 1 },
  menuScroll: { flexGrow: 1, paddingHorizontal: 28, paddingVertical: 24, justifyContent: "center", maxWidth: 1180, alignSelf: "center", width: "100%" },
  menuHero: { flexDirection: "row", alignItems: "center", gap: 18, marginBottom: 26 },
  logoOrb: { width: 72, height: 72, borderRadius: 36, borderWidth: 2, borderColor: "#39B7FF", backgroundColor: "#281456", alignItems: "center", justifyContent: "center", shadowColor: "#FF3FC7", shadowOpacity: 0.8, shadowRadius: 18, shadowOffset: { width: 0, height: 0 }, elevation: 12 },
  logoStar: { color: "#FF3FC7", fontSize: 42, textShadowColor: "#39B7FF", textShadowRadius: 10 },
  brandEyebrow: { color: "#39B7FF", fontSize: 12, fontWeight: "900", letterSpacing: 3 },
  brandTitle: { color: "#FFF8FF", fontSize: 32, fontWeight: "900", letterSpacing: 1 },
  brandSubtitle: { color: "#B9ABD9", fontSize: 13, marginTop: 4 },
  menuGrid: { flexDirection: "row", gap: 18, alignItems: "stretch" },
  menuPrimaryColumn: { flex: 1.3, gap: 12 },
  menuSecondaryColumn: { flex: 1, gap: 8 },
  button: { minHeight: 52, paddingHorizontal: 18, borderRadius: 16, backgroundColor: "#6F2DBD", borderWidth: 1, borderColor: "#A967E7", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9, shadowColor: "#000", shadowOpacity: 0.2, shadowRadius: 8, shadowOffset: { width: 0, height: 4 }, elevation: 3 },
  buttonCompact: { minHeight: 40, paddingHorizontal: 13, borderRadius: 12, shadowOpacity: 0, elevation: 0 },
  buttonSecondary: { backgroundColor: "#2D5F89", borderColor: "#5DCBFF" },
  buttonDanger: { backgroundColor: "#5D244B", borderColor: "#FF5C7A" },
  buttonGhost: { backgroundColor: "rgba(255,248,255,0.07)", borderColor: "rgba(255,248,255,0.22)" },
  buttonText: { color: "#FFF8FF", fontSize: 15, fontWeight: "900" },
  buttonGhostText: { color: "#EEE5FF", fontSize: 14 },
  buttonIcon: { color: "#FFD166", fontSize: 18, fontWeight: "900" },
  pressed: { opacity: 0.76, transform: [{ scale: 0.97 }] },
  nameCard: { borderRadius: 16, backgroundColor: "rgba(255,248,255,0.07)", borderWidth: 1, borderColor: "rgba(255,248,255,0.16)", paddingHorizontal: 16, paddingVertical: 11 },
  cardLabel: { color: "#B9ABD9", fontSize: 12, fontWeight: "800", marginBottom: 4 },
  nameInput: { color: "#FFF8FF", fontSize: 16, fontWeight: "800", paddingVertical: 2 },
  offlineBanner: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 26, paddingVertical: 11, paddingHorizontal: 15, backgroundColor: "rgba(101,214,138,0.11)", borderRadius: 14, borderWidth: 1, borderColor: "rgba(101,214,138,0.28)" },
  offlineDot: { color: "#65D68A", fontSize: 10 },
  offlineText: { color: "#CDEED6", fontSize: 12, fontWeight: "700", textAlign: "center" },
  gameRoot: { flex: 1, backgroundColor: "#120B2E", padding: 12, gap: 10 },
  hudTop: { minHeight: 58, flexDirection: "row", alignItems: "center", gap: 14 },
  hudEyebrow: { color: "#B9ABD9", fontSize: 11, fontWeight: "800", letterSpacing: 1 },
  hudLocation: { color: "#FFF8FF", fontSize: 21, fontWeight: "900" },
  hudStats: { flex: 1, flexDirection: "row", justifyContent: "center", gap: 8 },
  statPill: { flexDirection: "row", alignItems: "center", gap: 7, paddingHorizontal: 11, paddingVertical: 6, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.08)" },
  statLabel: { color: "#AFA3C9", fontSize: 10, fontWeight: "700" },
  statValue: { color: "#FFF8FF", fontSize: 14, fontWeight: "900" },
  hudExit: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(255,92,122,0.13)", borderWidth: 1, borderColor: "#FF5C7A" },
  hudExitText: { color: "#FFB3C1", fontSize: 27, lineHeight: 28 },
  worldCanvas: { flex: 1, borderRadius: 24, overflow: "hidden", minHeight: 260, position: "relative", borderWidth: 1, borderColor: "rgba(255,248,255,0.22)" },
  pixelSun: { position: "absolute", right: "14%", top: "12%", width: 64, height: 64, borderRadius: 32, backgroundColor: "rgba(255,209,102,0.33)", alignItems: "center", justifyContent: "center" },
  worldGlow: { position: "absolute", left: "8%", bottom: "10%", width: "72%", height: "34%", borderRadius: 90, backgroundColor: "rgba(101,214,138,0.22)" },
  worldLabel: { position: "absolute", left: 22, top: 20, padding: 12, borderRadius: 14, backgroundColor: "rgba(18,11,46,0.48)" },
  worldLabelTitle: { color: "#FFF8FF", fontSize: 18, fontWeight: "900" },
  worldLabelSubtitle: { color: "#D6C6F5", fontSize: 11, marginTop: 3 },
  playerSprite: { position: "absolute", alignItems: "center", transform: [{ translateX: -20 }, { translateY: -20 }] },
  playerEmoji: { fontSize: 42, textShadowColor: "#FF3FC7", textShadowRadius: 12 },
  playerName: { color: "#FFF8FF", fontSize: 10, fontWeight: "900", backgroundColor: "rgba(18,11,46,0.6)", paddingHorizontal: 6, borderRadius: 5 },
  resource: { position: "absolute", width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(255,248,255,0.18)", borderWidth: 1, borderColor: "rgba(255,248,255,0.36)" },
  resourceA: { left: "24%", bottom: "26%" },
  resourceB: { right: "28%", bottom: "20%" },
  worldHint: { position: "absolute", bottom: 14, left: 18, right: 18, padding: 10, borderRadius: 11, backgroundColor: "rgba(18,11,46,0.72)" },
  worldHintText: { color: "#FFF8FF", fontSize: 12, fontWeight: "700", textAlign: "center" },
  controlLayer: { position: "absolute", left: 22, right: 22, bottom: 84, flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end", pointerEvents: "box-none" },
  joystick: { alignItems: "center", gap: 3 },
  joystickRing: { width: 94, height: 94, borderRadius: 47, borderWidth: 2, borderColor: "rgba(255,248,255,0.48)", backgroundColor: "rgba(18,11,46,0.42)", alignItems: "center", justifyContent: "center" },
  joystickKnob: { width: 50, height: 50, borderRadius: 25, backgroundColor: "#6F2DBD", borderWidth: 2, borderColor: "#FF3FC7", alignItems: "center", justifyContent: "center" },
  joystickText: { color: "#FFF8FF", fontSize: 23 },
  controlCaption: { color: "#EFE4FF", fontSize: 10, fontWeight: "800" },
  actionCluster: { flexDirection: "row", gap: 8, alignItems: "flex-end" },
  actionButton: { width: 70, height: 70, borderRadius: 20, backgroundColor: "rgba(18,11,46,0.78)", borderWidth: 1, borderColor: "#39B7FF", alignItems: "center", justifyContent: "center" },
  actionIcon: { fontSize: 22, color: "#FFD166" },
  actionText: { color: "#FFF8FF", fontSize: 11, fontWeight: "900", marginTop: 3 },
  gameNav: { flexDirection: "row", gap: 7, justifyContent: "center" },
  overlay: { ...StyleSheet.absoluteFillObject, zIndex: 20, backgroundColor: "rgba(12,7,28,0.82)", padding: 18, justifyContent: "center" },
  panel: { maxHeight: "92%", width: "100%", maxWidth: 980, alignSelf: "center", backgroundColor: "#1E153B", borderWidth: 1, borderColor: "#8055C9", borderRadius: 24, padding: 18, shadowColor: "#000", shadowOpacity: 0.5, shadowRadius: 20, shadowOffset: { width: 0, height: 10 }, elevation: 12 },
  panelHeader: { flexDirection: "row", alignItems: "center", marginBottom: 14 },
  panelTitle: { color: "#FFF8FF", fontSize: 23, fontWeight: "900" },
  panelSubtitle: { color: "#B9ABD9", fontSize: 12, marginTop: 3 },
  closeButton: { width: 42, height: 42, borderRadius: 13, backgroundColor: "rgba(255,248,255,0.08)", alignItems: "center", justifyContent: "center" },
  closeText: { color: "#FFF8FF", fontSize: 28, lineHeight: 29 },
  panelIntro: { color: "#D6C6F5", lineHeight: 20, fontSize: 13, marginBottom: 12 },
  saveRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: "rgba(255,248,255,0.1)" },
  saveSlotBadge: { width: 40, height: 40, borderRadius: 13, backgroundColor: "#6F2DBD", alignItems: "center", justifyContent: "center" },
  saveSlotText: { color: "#FFF8FF", fontSize: 18, fontWeight: "900" },
  saveTitle: { color: "#FFF8FF", fontSize: 14, fontWeight: "900" },
  saveMeta: { color: "#AFA3C9", fontSize: 11, marginTop: 3 },
  rowActions: { flexDirection: "row", gap: 6 },
  searchRow: { flexDirection: "row", gap: 6, alignItems: "center", flexWrap: "wrap", marginBottom: 10 },
  searchInput: { minWidth: 160, flex: 1, color: "#FFF8FF", backgroundColor: "rgba(255,248,255,0.08)", borderRadius: 11, paddingHorizontal: 12, paddingVertical: 9, borderWidth: 1, borderColor: "rgba(255,248,255,0.16)" },
  filterChip: { paddingHorizontal: 9, paddingVertical: 8, borderRadius: 10, backgroundColor: "rgba(255,248,255,0.08)" },
  filterChipActive: { backgroundColor: "#6F2DBD", borderWidth: 1, borderColor: "#FF3FC7" },
  filterText: { color: "#EFE4FF", fontSize: 11, fontWeight: "800" },
  itemGrid: { flexDirection: "row", flexWrap: "wrap", gap: 9, paddingVertical: 6 },
  itemCard: { width: 90, minHeight: 86, padding: 8, borderRadius: 14, backgroundColor: "rgba(255,248,255,0.06)", borderWidth: 1, borderColor: "rgba(255,248,255,0.12)", alignItems: "center" },
  itemCardActive: { borderColor: "#39B7FF", backgroundColor: "rgba(57,183,255,0.12)" },
  itemIcon: { fontSize: 26 },
  itemName: { color: "#FFF8FF", fontSize: 11, fontWeight: "800", textAlign: "center", marginTop: 4 },
  itemCount: { color: "#FFD166", fontSize: 11, fontWeight: "900", marginTop: 2 },
  detailCard: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 12, padding: 12, borderRadius: 14, backgroundColor: "rgba(111,45,189,0.18)", borderWidth: 1, borderColor: "rgba(169,103,231,0.5)" },
  detailIcon: { width: 52, height: 52, borderRadius: 14, backgroundColor: "rgba(255,248,255,0.09)", alignItems: "center", justifyContent: "center" },
  detailTitle: { color: "#FFF8FF", fontSize: 15, fontWeight: "900" },
  detailDescription: { color: "#D6C6F5", fontSize: 12, marginTop: 3 },
  detailMeta: { color: "#FFD166", fontSize: 11, marginTop: 5, fontWeight: "800" },
  listCard: { flexDirection: "row", alignItems: "center", gap: 12, padding: 12, marginBottom: 8, borderRadius: 15, backgroundColor: "rgba(255,248,255,0.055)", borderWidth: 1, borderColor: "rgba(255,248,255,0.11)" },
  mapCard: { flexDirection: "row", alignItems: "center", gap: 12, padding: 14, marginBottom: 9, borderRadius: 16, borderWidth: 1, borderColor: "rgba(255,248,255,0.3)" },
  mapCardActive: { borderColor: "#FFD166", shadowColor: "#FFD166", shadowOpacity: 0.35, shadowRadius: 8, shadowOffset: { width: 0, height: 2 } },
  mapPin: { width: 38, height: 38, borderRadius: 14, backgroundColor: "rgba(18,11,46,0.38)", alignItems: "center", justifyContent: "center" },
  listTitle: { color: "#FFF8FF", fontSize: 14, fontWeight: "900" },
  listDescription: { color: "#D0C1EC", fontSize: 12, marginTop: 4, lineHeight: 17 },
  listMeta: { color: "#FFD166", fontSize: 11, marginTop: 5, fontWeight: "700" },
  recipeIcon: { width: 42, textAlign: "center", fontSize: 28 },
  questIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: "#6F2DBD", alignItems: "center", justifyContent: "center" },
  questDone: { backgroundColor: "#2B8451" },
  statusText: { color: "#B9ABD9", fontSize: 11, fontWeight: "800" },
  statusDone: { color: "#65D68A" },
  achievementUnlocked: { borderColor: "rgba(255,209,102,0.5)", backgroundColor: "rgba(255,209,102,0.08)" },
  sectionHeading: { color: "#39B7FF", fontSize: 13, fontWeight: "900", letterSpacing: 0.5, marginTop: 9, marginBottom: 9 },
  battleArena: { flexDirection: "row", alignItems: "center", justifyContent: "space-around", paddingVertical: 24, borderRadius: 18, backgroundColor: "rgba(18,11,46,0.5)" },
  battleUnit: { width: "34%", alignItems: "center" },
  battleEmoji: { fontSize: 58 },
  battleName: { color: "#FFF8FF", fontSize: 14, fontWeight: "900", marginTop: 4 },
  hpText: { color: "#D6C6F5", fontSize: 11, marginTop: 5 },
  hpBar: { height: 9, width: "100%", borderRadius: 5, marginTop: 6, backgroundColor: "#38294F", overflow: "hidden" },
  hpFill: { height: "100%", borderRadius: 5, backgroundColor: "#65D68A" },
  enemyHp: { backgroundColor: "#FF5C7A" },
  battleVs: { color: "#FF3FC7", fontSize: 20, fontWeight: "900" },
  battleActions: { flexDirection: "row", gap: 8, justifyContent: "center", marginTop: 14 },
  battleTip: { color: "#AFA3C9", fontSize: 12, textAlign: "center", lineHeight: 18, marginTop: 15 },
  settingRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: "rgba(255,248,255,0.1)" },
  performanceRow: { flexDirection: "row", gap: 7, flexWrap: "wrap" },
  performanceChip: { paddingHorizontal: 15, paddingVertical: 10, borderRadius: 12, backgroundColor: "rgba(255,248,255,0.08)" },
  performanceActive: { backgroundColor: "#6F2DBD", borderWidth: 1, borderColor: "#FF3FC7" },
  settingHint: { color: "#AFA3C9", fontSize: 12, lineHeight: 18, marginTop: 14 },
  guideHero: { flexDirection: "row", gap: 12, alignItems: "center", padding: 13, borderRadius: 15, backgroundColor: "rgba(57,183,255,0.1)", borderWidth: 1, borderColor: "rgba(57,183,255,0.3)" },
  guildHero: { flexDirection: "row", gap: 12, alignItems: "center", padding: 14, borderRadius: 16, backgroundColor: "rgba(255,209,102,0.1)", borderWidth: 1, borderColor: "rgba(255,209,102,0.35)" },
  guildCrest: { width: 44, height: 44, borderRadius: 14, backgroundColor: "#6F2DBD", color: "#FFD166", fontSize: 28, textAlign: "center", textAlignVertical: "center" },
  guideHeroIcon: { color: "#39B7FF", fontSize: 32 },
  guideText: { color: "#D6C6F5", fontSize: 13, lineHeight: 21, marginBottom: 7 },
  codeBlock: { padding: 13, borderRadius: 13, backgroundColor: "#100B23", borderWidth: 1, borderColor: "rgba(57,183,255,0.25)", marginBottom: 8 },
  codeText: { color: "#A9E6FF", fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace", fontSize: 12, lineHeight: 19 },
  guideButtons: { flexDirection: "row", gap: 8, marginTop: 9 },
  modDrop: { alignItems: "center", padding: 25, borderRadius: 17, borderWidth: 1, borderStyle: "dashed", borderColor: "#39B7FF", backgroundColor: "rgba(57,183,255,0.08)" },
  modIcon: { color: "#FF3FC7", fontSize: 48, marginBottom: 8 },
  modStatus: { padding: 13, marginTop: 12, borderRadius: 14, backgroundColor: "rgba(255,248,255,0.06)" },
  aboutMark: { alignItems: "center", paddingVertical: 12 },
  aboutType: { color: "#39B7FF", fontSize: 13, fontWeight: "900", letterSpacing: 1, marginTop: 4 },
  aboutText: { color: "#D6C6F5", fontSize: 14, lineHeight: 23, textAlign: "center", marginVertical: 12 },
  exitMask: { ...StyleSheet.absoluteFillObject, zIndex: 50, backgroundColor: "#FFF8FF", alignItems: "center", justifyContent: "center" },
  exitText: { color: "#6F2DBD", fontSize: 18, fontWeight: "900" },
  toast: { position: "absolute", left: 24, right: 24, bottom: 22, zIndex: 80, paddingHorizontal: 16, paddingVertical: 13, borderRadius: 15, backgroundColor: "#2D2152", borderWidth: 1, borderColor: "#8055C9", shadowColor: "#000", shadowOpacity: 0.3, shadowRadius: 9, shadowOffset: { width: 0, height: 4 }, elevation: 5 },
  toastSuccess: { backgroundColor: "#17452F", borderColor: "#65D68A" },
  toastDanger: { backgroundColor: "#4A2037", borderColor: "#FF5C7A" },
  toastText: { color: "#FFF8FF", fontSize: 13, fontWeight: "800", textAlign: "center" },
});

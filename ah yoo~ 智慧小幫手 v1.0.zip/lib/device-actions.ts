import * as IntentLauncher from "expo-intent-launcher";
import { Alert, Linking, Platform } from "react-native";

export async function openAndroidSettings(action: string, title: string): Promise<void> {
  try {
    if (Platform.OS === "android") {
      await IntentLauncher.startActivityAsync(action);
      return;
    }
    await Linking.openSettings();
  } catch {
    Alert.alert(title, "目前無法開啟指定系統頁面，請在裝置設定中手動調整。");
  }
}

export async function openExternalUrl(url: string, title = "目前無法開啟"): Promise<void> {
  try {
    await Linking.openURL(url);
  } catch {
    Alert.alert(title, "這項捷徑在此裝置上不可用，請確認已安裝對應服務。" );
  }
}

export async function dialNumber(number: string): Promise<void> {
  const normalized = number.replace(/[^0-9+*#]/g, "");
  if (!normalized) {
    Alert.alert("電話號碼無效", "請選擇包含有效電話號碼的聯絡人。");
    return;
  }
  await openExternalUrl(`tel:${normalized}`, "目前無法開啟撥號介面");
}

export async function openKnownApplication(
  packageName: string,
  fallbackUrl: string,
  title: string,
): Promise<void> {
  if (Platform.OS === "android") {
    try {
      IntentLauncher.openApplication(packageName);
      return;
    } catch {
      // Fall back to an external URI below when the package is unavailable.
    }
  }
  await openExternalUrl(fallbackUrl, title);
}

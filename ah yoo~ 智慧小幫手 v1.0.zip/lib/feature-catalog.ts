import type MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import type { ComponentProps } from "react";

export type FeatureId =
  | "profile"
  | "launcher"
  | "usage"
  | "quick-actions"
  | "network"
  | "dialer"
  | "device"
  | "feedback"
  | "finder"
  | "voice-note"
  | "sos"
  | "mystery"
  | "clipboard"
  | "focus"
  | "cleaner"
  | "floating";

export type FeatureDefinition = {
  id: FeatureId;
  title: string;
  shortTitle: string;
  description: string;
  icon: ComponentProps<typeof MaterialCommunityIcons>["name"];
  tint: string;
  softTint: string;
};

export const features: FeatureDefinition[] = [
  { id: "profile", title: "個人檔案", shortTitle: "檔案", description: "設定與裝置", icon: "account-circle-outline", tint: "#1565D8", softTint: "#E8F0FF" },
  { id: "launcher", title: "App 與遊戲", shortTitle: "啟動", description: "常用捷徑", icon: "rocket-launch-outline", tint: "#7C4DFF", softTint: "#F0EAFF" },
  { id: "usage", title: "使用時間", shortTitle: "使用", description: "日週月統計", icon: "chart-donut-variant", tint: "#D1681B", softTint: "#FFF0E2" },
  { id: "quick-actions", title: "快捷搜尋", shortTitle: "快捷", description: "搜尋與設定", icon: "magnify-expand", tint: "#0A8D73", softTint: "#E0F7F1" },
  { id: "network", title: "網路診斷", shortTitle: "網路", description: "連線品質", icon: "wifi-cog", tint: "#0785D1", softTint: "#E1F3FF" },
  { id: "dialer", title: "快速撥號", shortTitle: "撥號", description: "聯絡人", icon: "phone-outline", tint: "#16A36A", softTint: "#E2F8EC" },
  { id: "device", title: "裝置資訊", shortTitle: "裝置", description: "硬體與電力", icon: "cellphone-information", tint: "#556579", softTint: "#EEF2F6" },
  { id: "feedback", title: "意見回饋", shortTitle: "回饋", description: "建議與回報", icon: "message-text-outline", tint: "#B74DA0", softTint: "#FBEAF7" },
  { id: "finder", title: "語音尋找", shortTitle: "尋找", description: "前景聆聽", icon: "microphone-message", tint: "#DE5D4F", softTint: "#FFE9E5" },
  { id: "voice-note", title: "語音備忘", shortTitle: "備忘", description: "錄音與整理", icon: "microphone-outline", tint: "#8B5CF6", softTint: "#F0EAFF" },
  { id: "sos", title: "緊急 SOS", shortTitle: "SOS", description: "求助與定位", icon: "alert-decagram-outline", tint: "#D94252", softTint: "#FFE8EB" },
  { id: "mystery", title: "每日知識", shortTitle: "知識", description: "一日一題", icon: "lightbulb-on-outline", tint: "#E59B13", softTint: "#FFF4D8" },
  { id: "clipboard", title: "剪貼簿中心", shortTitle: "剪貼", description: "主動擷取", icon: "content-paste", tint: "#3574C6", softTint: "#E6F0FF" },
  { id: "focus", title: "智慧專注", shortTitle: "專注", description: "番茄與倒數", icon: "timer-sand", tint: "#0A9E88", softTint: "#DDF8F1" },
  { id: "cleaner", title: "儲存空間", shortTitle: "空間", description: "容量管理", icon: "broom", tint: "#718096", softTint: "#EEF2F7" },
  { id: "floating", title: "懸浮快捷", shortTitle: "懸浮", description: "系統授權", icon: "circle-double", tint: "#5B6EE1", softTint: "#E9EBFF" },
];

export function getFeature(id: string | undefined): FeatureDefinition | undefined {
  return features.find((feature) => feature.id === id);
}

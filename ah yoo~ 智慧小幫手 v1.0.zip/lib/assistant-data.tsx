import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

const STORAGE_KEY = "sixteen-grid-assistant.workspace.v1";

export type EmergencyContact = {
  id: string;
  name: string;
  phone: string;
};

export type VoiceNote = {
  id: string;
  title: string;
  uri: string;
  createdAt: string;
  durationSeconds: number;
  tags: string[];
  transcript?: string;
};

export type ClipboardEntry = {
  id: string;
  text: string;
  kind: "text" | "url";
  createdAt: string;
  pinned: boolean;
};

export type FocusSession = {
  id: string;
  durationMinutes: number;
  completedAt: string;
  mode: "pomodoro" | "timer";
};

export type AssistantSettings = {
  profileName: string;
  finderPhrase: string;
  feedbackAudioEnabled: boolean;
  feedbackVolume: number;
  floatingWidgetSize: "small" | "medium" | "large";
  floatingWidgetOpacity: number;
  floatingWidgetEnabled: boolean;
};

type AssistantWorkspace = {
  settings: AssistantSettings;
  favoriteContactIds: string[];
  emergencyContact: EmergencyContact | null;
  voiceNotes: VoiceNote[];
  clipboardEntries: ClipboardEntry[];
  focusSessions: FocusSession[];
};

const defaultSettings: AssistantSettings = {
  profileName: "",
  finderPhrase: "小助手你在哪？",
  feedbackAudioEnabled: true,
  feedbackVolume: 0.45,
  floatingWidgetSize: "medium",
  floatingWidgetOpacity: 0.82,
  floatingWidgetEnabled: false,
};

const defaultWorkspace: AssistantWorkspace = {
  settings: defaultSettings,
  favoriteContactIds: [],
  emergencyContact: null,
  voiceNotes: [],
  clipboardEntries: [],
  focusSessions: [],
};

type AssistantDataContextValue = AssistantWorkspace & {
  isHydrated: boolean;
  updateSettings: (patch: Partial<AssistantSettings>) => void;
  toggleFavoriteContact: (contactId: string) => void;
  setEmergencyContact: (contact: EmergencyContact | null) => void;
  saveVoiceNote: (note: VoiceNote) => void;
  removeVoiceNote: (noteId: string) => void;
  captureClipboardEntry: (entry: ClipboardEntry) => void;
  toggleClipboardPinned: (entryId: string) => void;
  removeClipboardEntry: (entryId: string) => void;
  addFocusSession: (session: FocusSession) => void;
  clearLocalData: () => Promise<void>;
};

const AssistantDataContext = createContext<AssistantDataContextValue | null>(null);

function normalizeWorkspace(value: Partial<AssistantWorkspace> | null): AssistantWorkspace {
  return {
    settings: { ...defaultSettings, ...(value?.settings ?? {}) },
    favoriteContactIds: value?.favoriteContactIds ?? [],
    emergencyContact: value?.emergencyContact ?? null,
    voiceNotes: value?.voiceNotes ?? [],
    clipboardEntries: value?.clipboardEntries ?? [],
    focusSessions: value?.focusSessions ?? [],
  };
}

export function AssistantDataProvider({ children }: { children: React.ReactNode }) {
  const [workspace, setWorkspace] = useState<AssistantWorkspace>(defaultWorkspace);
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    let active = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => {
        if (!active || !raw) return;
        try {
          setWorkspace(normalizeWorkspace(JSON.parse(raw) as Partial<AssistantWorkspace>));
        } catch {
          setWorkspace(defaultWorkspace);
        }
      })
      .finally(() => {
        if (active) setIsHydrated(true);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!isHydrated) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(workspace)).catch(() => undefined);
  }, [isHydrated, workspace]);

  const updateSettings = useCallback((patch: Partial<AssistantSettings>) => {
    setWorkspace((current) => ({
      ...current,
      settings: { ...current.settings, ...patch },
    }));
  }, []);

  const toggleFavoriteContact = useCallback((contactId: string) => {
    setWorkspace((current) => {
      const exists = current.favoriteContactIds.includes(contactId);
      return {
        ...current,
        favoriteContactIds: exists
          ? current.favoriteContactIds.filter((id) => id !== contactId)
          : [...current.favoriteContactIds, contactId],
      };
    });
  }, []);

  const setEmergencyContact = useCallback((contact: EmergencyContact | null) => {
    setWorkspace((current) => ({ ...current, emergencyContact: contact }));
  }, []);

  const saveVoiceNote = useCallback((note: VoiceNote) => {
    setWorkspace((current) => ({
      ...current,
      voiceNotes: [note, ...current.voiceNotes.filter((item) => item.id !== note.id)],
    }));
  }, []);

  const removeVoiceNote = useCallback((noteId: string) => {
    setWorkspace((current) => ({
      ...current,
      voiceNotes: current.voiceNotes.filter((note) => note.id !== noteId),
    }));
  }, []);

  const captureClipboardEntry = useCallback((entry: ClipboardEntry) => {
    setWorkspace((current) => ({
      ...current,
      clipboardEntries: [entry, ...current.clipboardEntries.filter((item) => item.text !== entry.text)].slice(0, 50),
    }));
  }, []);

  const toggleClipboardPinned = useCallback((entryId: string) => {
    setWorkspace((current) => ({
      ...current,
      clipboardEntries: current.clipboardEntries.map((entry) =>
        entry.id === entryId ? { ...entry, pinned: !entry.pinned } : entry,
      ),
    }));
  }, []);

  const removeClipboardEntry = useCallback((entryId: string) => {
    setWorkspace((current) => ({
      ...current,
      clipboardEntries: current.clipboardEntries.filter((entry) => entry.id !== entryId),
    }));
  }, []);

  const addFocusSession = useCallback((session: FocusSession) => {
    setWorkspace((current) => ({
      ...current,
      focusSessions: [session, ...current.focusSessions].slice(0, 365),
    }));
  }, []);

  const clearLocalData = useCallback(async () => {
    setWorkspace(defaultWorkspace);
    await AsyncStorage.removeItem(STORAGE_KEY);
  }, []);

  const value = useMemo(
    () => ({
      ...workspace,
      isHydrated,
      updateSettings,
      toggleFavoriteContact,
      setEmergencyContact,
      saveVoiceNote,
      removeVoiceNote,
      captureClipboardEntry,
      toggleClipboardPinned,
      removeClipboardEntry,
      addFocusSession,
      clearLocalData,
    }),
    [addFocusSession, captureClipboardEntry, clearLocalData, isHydrated, removeClipboardEntry, removeVoiceNote, saveVoiceNote, setEmergencyContact, toggleClipboardPinned, toggleFavoriteContact, updateSettings, workspace],
  );

  return <AssistantDataContext.Provider value={value}>{children}</AssistantDataContext.Provider>;
}

export function useAssistantData(): AssistantDataContextValue {
  const context = useContext(AssistantDataContext);
  if (!context) throw new Error("useAssistantData must be used within AssistantDataProvider");
  return context;
}

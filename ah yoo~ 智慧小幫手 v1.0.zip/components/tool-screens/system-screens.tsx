import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import * as Battery from "expo-battery";
import * as Device from "expo-device";
import * as FileSystem from "expo-file-system/legacy";
import * as IntentLauncher from "expo-intent-launcher";
import * as Network from "expo-network";
import { useEffect, useState } from "react";
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

import { CompactButton, KeyValueRow, StatusCard, SurfaceCard } from "@/components/assistant-ui";
import { useAssistantData } from "@/lib/assistant-data";
import { openAndroidSettings, openExternalUrl, openKnownApplication } from "@/lib/device-actions";
import { useColors } from "@/hooks/use-colors";

type LauncherShortcut = { title: string; packageName: string; fallbackUrl: string; icon: "gmail" | "message-processing-outline" | "google-chrome" | "gamepad-variant-outline" };

const launcherShortcuts: LauncherShortcut[] = [
  { title: "Gmail", packageName: "com.google.android.gm", fallbackUrl: "https://mail.google.com", icon: "gmail" },
  { title: "訊息", packageName: "com.google.android.apps.messaging", fallbackUrl: "sms:", icon: "message-processing-outline" },
  { title: "Chrome", packageName: "com.android.chrome", fallbackUrl: "https://www.google.com", icon: "google-chrome" },
  { title: "遊戲中心", packageName: "com.google.android.play.games", fallbackUrl: "https://play.google.com/store/games", icon: "gamepad-variant-outline" },
];

export function LauncherScreen() {
  const colors = useColors();
  const [query, setQuery] = useState("");
  const [launching, setLaunching] = useState<string | null>(null);
  const filtered = launcherShortcuts.filter((shortcut) => shortcut.title.toLowerCase().includes(query.trim().toLowerCase()));

  const launchShortcut = async (shortcut: LauncherShortcut) => {
    setLaunching(shortcut.title);
    await new Promise((resolve) => setTimeout(resolve, 450));
    await new Promise((resolve) => setTimeout(resolve, 450));
    await new Promise((resolve) => setTimeout(resolve, 450));
    await openKnownApplication(shortcut.packageName, shortcut.fallbackUrl, `無法開啟 ${shortcut.title}`);
    setLaunching(null);
  };

  return (
    <View style={styles.stack}>
      <StatusCard
        icon="shield-lock-outline"
        tone="warning"
        title="使用精選捷徑，而非掃描完整 App 清單"
        description="Android 11 以上會限制已安裝 App 的可見性；本版本不要求高風險的完整 App 清單權限。"
      />
      <TextInput value={query} onChangeText={setQuery} placeholder="搜尋捷徑" placeholderTextColor={colors.muted} returnKeyType="done" style={[styles.input, { color: colors.foreground, backgroundColor: colors.surface, borderColor: colors.border }]} />
      {launching ? <StatusCard icon="rocket-launch-outline" title={`正在開啟 ${launching}`} description="3 → 2 → 1，正在交由 Android 開啟可用的目標。" /> : null}
      <SurfaceCard style={styles.listCard}>
        {filtered.map((shortcut) => (
          <Pressable key={shortcut.title} onPress={() => launchShortcut(shortcut)} style={({ pressed }) => [styles.shortcutRow, { borderBottomColor: colors.border }, pressed && styles.pressed]}>
            <View style={[styles.shortcutIcon, { backgroundColor: `${String(colors.primary)}16` }]}>
              <MaterialCommunityIcons name={shortcut.icon} size={21} color={colors.primary} />
            </View>
            <Text style={[styles.shortcutTitle, { color: colors.foreground }]}>{shortcut.title}</Text>
            <MaterialCommunityIcons name="chevron-right" size={21} color={colors.muted} />
          </Pressable>
        ))}
        {filtered.length === 0 ? <Text style={[styles.emptyText, { color: colors.muted }]}>找不到符合的捷徑。</Text> : null}
      </SurfaceCard>
    </View>
  );
}

export function UsageScreen() {
  return (
    <View style={styles.stack}>
      <StatusCard
        icon="chart-box-outline"
        tone="warning"
        title="需要使用狀況存取權"
        description="Android 會將 App 使用時間列為特殊存取權限。本生成版本提供系統設定入口，但不在未授權時顯示虛構統計。"
        actionLabel="開啟使用狀況設定"
        onAction={() => openAndroidSettings(IntentLauncher.ActivityAction.USAGE_ACCESS_SETTINGS, "使用狀況存取")}
      />
      <SurfaceCard>
        <Text style={styles.placeholderTitle}>今日、每週與每月趨勢</Text>
        <Text style={styles.placeholderDescription}>授權後可由原生 UsageStats 整合模組提供資料。本 Expo 容器版不會擅自模擬 App 使用時數。</Text>
      </SurfaceCard>
    </View>
  );
}

const quickActions = [
  { title: "開啟 Wi‑Fi", icon: "wifi", action: () => openAndroidSettings(IntentLauncher.ActivityAction.PANEL_WIFI, "Wi‑Fi 設定") },
  { title: "行動數據", icon: "signal-cellular-3", action: () => openAndroidSettings(IntentLauncher.ActivityAction.DATA_USAGE_SETTINGS, "行動數據設定") },
  { title: "Gmail", icon: "gmail", action: () => openKnownApplication("com.google.android.gm", "https://mail.google.com", "無法開啟 Gmail") },
  { title: "訊息", icon: "message-processing-outline", action: () => openExternalUrl("sms:", "無法開啟訊息") },
  { title: "LINE", icon: "chat-outline", action: () => openExternalUrl("line://", "無法開啟 LINE") },
] as const;

export function QuickActionsScreen() {
  const colors = useColors();
  const [query, setQuery] = useState("");
  const performSearch = () => {
    const term = query.trim();
    if (!term) {
      Alert.alert("請輸入關鍵字", "輸入內容後即可交由瀏覽器進行網路搜尋。");
      return;
    }
    openExternalUrl(`https://www.google.com/search?q=${encodeURIComponent(term)}`, "無法開啟網頁搜尋");
  };
  return (
    <View style={styles.stack}>
      <SurfaceCard>
        <Text style={[styles.toolLabel, { color: colors.muted }]}>網路搜尋</Text>
        <View style={styles.searchRow}>
          <TextInput value={query} onChangeText={setQuery} onSubmitEditing={performSearch} placeholder="輸入關鍵字" placeholderTextColor={colors.muted} returnKeyType="search" style={[styles.searchInput, { color: colors.foreground, backgroundColor: colors.background, borderColor: colors.border }]} />
          <CompactButton label="搜尋" onPress={performSearch} icon="magnify" />
        </View>
      </SurfaceCard>
      <SurfaceCard style={styles.listCard}>
        {quickActions.map((item) => (
          <Pressable key={item.title} onPress={item.action} style={({ pressed }) => [styles.shortcutRow, { borderBottomColor: colors.border }, pressed && styles.pressed]}>
            <MaterialCommunityIcons name={item.icon} size={21} color={colors.primary} />
            <Text style={[styles.shortcutTitle, { color: colors.foreground }]}>{item.title}</Text>
            <MaterialCommunityIcons name="open-in-new" size={17} color={colors.muted} />
          </Pressable>
        ))}
      </SurfaceCard>
      <StatusCard icon="information-outline" title="系統開關由 Android 管理" description="此頁只開啟對應設定或已安裝服務，不會未經確認地切換 Wi‑Fi 或行動數據。" />
    </View>
  );
}

type NetworkSnapshot = { connection: string; internet: string; type: string; ip: string };

export function NetworkScreen() {
  const colors = useColors();
  const [snapshot, setSnapshot] = useState<NetworkSnapshot | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const refresh = async () => {
    setIsLoading(true);
    try {
      const [state, ip] = await Promise.all([Network.getNetworkStateAsync(), Network.getIpAddressAsync()]);
      setSnapshot({
        connection: state.isConnected ? "已連線" : "未連線",
        internet: state.isInternetReachable ? "可連上網際網路" : "尚未確認／無法連線",
        type: String(state.type ?? "UNKNOWN"),
        ip: ip === "0.0.0.0" ? "此裝置不提供" : ip,
      });
    } catch {
      Alert.alert("目前無法使用此功能", "無法讀取網路診斷資訊，請確認網路狀態後再試。" );
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => { refresh(); }, []);
  return (
    <View style={styles.stack}>
      <SurfaceCard>
        <View style={styles.cardHeader}>
          <View>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>連線診斷</Text>
            <Text style={[styles.cardDescription, { color: colors.muted }]}>僅顯示裝置 API 可取得的網路資訊。</Text>
          </View>
          <CompactButton label={isLoading ? "讀取中" : "重新整理"} onPress={refresh} icon="refresh" />
        </View>
        <KeyValueRow label="連線狀態" value={snapshot?.connection ?? "正在讀取"} icon="lan-connect" />
        <KeyValueRow label="網際網路" value={snapshot?.internet ?? "正在讀取"} icon="earth" />
        <KeyValueRow label="網路類型" value={snapshot?.type ?? "正在讀取"} icon="signal" />
        <KeyValueRow label="IPv4 位址" value={snapshot?.ip ?? "正在讀取"} icon="ip-network-outline" />
      </SurfaceCard>
      <StatusCard icon="wifi-alert" tone="warning" title="Wi‑Fi 名稱與訊號品質" description="目前使用的跨平台 API 不提供 SSID、附近 Wi‑Fi 掃描或精確訊號強度；不會在未支援時顯示猜測數值。" actionLabel="開啟 Wi‑Fi 設定" onAction={() => openAndroidSettings(IntentLauncher.ActivityAction.PANEL_WIFI, "Wi‑Fi 設定")} />
    </View>
  );
}

function formatBytes(bytes: number | null): string {
  if (bytes == null || bytes < 0) return "此裝置不提供";
  return `${(bytes / 1024 / 1024 / 1024).toFixed(1)} GB`;
}

export function DeviceInfoScreen() {
  const colors = useColors();
  const [storage, setStorage] = useState<{ total: number | null; free: number | null; battery: number; status: string }>({ total: null, free: null, battery: -1, status: "正在讀取" });
  const refresh = async () => {
    try {
      const [total, free, battery, power] = await Promise.all([
        FileSystem.getTotalDiskCapacityAsync(),
        FileSystem.getFreeDiskStorageAsync(),
        Battery.getBatteryLevelAsync(),
        Battery.getPowerStateAsync(),
      ]);
      const status = power.batteryState === Battery.BatteryState.CHARGING ? "充電中" : power.batteryState === Battery.BatteryState.FULL ? "已充滿" : power.batteryState === Battery.BatteryState.UNPLUGGED ? "使用電池" : "此裝置不提供";
      setStorage({ total, free, battery, status });
    } catch {
      setStorage((previous) => ({ ...previous, status: "此裝置不提供" }));
    }
  };
  useEffect(() => { refresh(); }, []);
  const used = storage.total != null && storage.free != null ? storage.total - storage.free : null;
  return (
    <View style={styles.stack}>
      <SurfaceCard>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>系統與硬體</Text>
        <KeyValueRow label="品牌" value={Device.brand ?? "此裝置不提供"} icon="tag-outline" />
        <KeyValueRow label="型號" value={Device.modelName ?? "此裝置不提供"} icon="cellphone" />
        <KeyValueRow label="系統" value={[Device.osName, Device.osVersion].filter(Boolean).join(" ") || "此裝置不提供"} icon="android" />
        <KeyValueRow label="Android API" value={Device.platformApiLevel?.toString() ?? "此裝置不提供"} icon="code-tags" />
        <KeyValueRow label="記憶體" value={formatBytes(Device.totalMemory)} icon="memory" />
      </SurfaceCard>
      <SurfaceCard>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>儲存與電力</Text>
        <KeyValueRow label="總儲存空間" value={formatBytes(storage.total)} icon="harddisk" />
        <KeyValueRow label="已使用" value={formatBytes(used)} icon="chart-pie" />
        <KeyValueRow label="剩餘空間" value={formatBytes(storage.free)} icon="harddisk-plus" />
        <KeyValueRow label="電池電量" value={storage.battery >= 0 ? `${Math.round(storage.battery * 100)}%` : "此裝置不提供"} icon="battery" />
        <KeyValueRow label="電池狀態" value={storage.status} icon="battery-charging" />
      </SurfaceCard>
      <CompactButton label="重新整理資料" onPress={refresh} icon="refresh" />
    </View>
  );
}

export function CleanerScreen() {
  const colors = useColors();
  const [storage, setStorage] = useState<{ total: number | null; free: number | null }>({ total: null, free: null });
  const scan = async () => {
    try {
      const [total, free] = await Promise.all([FileSystem.getTotalDiskCapacityAsync(), FileSystem.getFreeDiskStorageAsync()]);
      setStorage({ total, free });
    } catch {
      Alert.alert("目前無法使用此功能", "裝置未提供儲存空間資訊。" );
    }
  };
  useEffect(() => { scan(); }, []);
  return (
    <View style={styles.stack}>
      <SurfaceCard>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>儲存空間概覽</Text>
        <KeyValueRow label="總容量" value={formatBytes(storage.total)} icon="harddisk" />
        <KeyValueRow label="可用容量" value={formatBytes(storage.free)} icon="harddisk-plus" />
        <KeyValueRow label="本 App 可用清理" value="僅限本 App 暫存資料" icon="broom" />
        <CompactButton label="重新掃描" onPress={scan} icon="refresh" />
      </SurfaceCard>
      <StatusCard icon="shield-alert-outline" tone="warning" title="不會清除其他 App 資料" description="Android 不允許一般 App 任意刪除其他 App 的快取或資料。請使用 Android 的系統儲存空間工具進行管理。" actionLabel="開啟儲存空間設定" onAction={() => openAndroidSettings(IntentLauncher.ActivityAction.INTERNAL_STORAGE_SETTINGS, "儲存空間設定")} />
    </View>
  );
}

export function FloatingWidgetScreen() {
  const colors = useColors();
  const { settings, updateSettings } = useAssistantData();
  return (
    <View style={styles.stack}>
      <StatusCard icon="circle-double" tone="warning" title="懸浮球需要 Android 原生前景服務" description="此 Expo 容器版可保留設定並開啟覆蓋其他 App 的系統授權頁，但尚未包含建立跨 App 懸浮視窗的原生服務；不會顯示為已啟用。" actionLabel="開啟覆蓋權限設定" onAction={() => openAndroidSettings(IntentLauncher.ActivityAction.MANAGE_OVERLAY_PERMISSION, "懸浮視窗權限")} />
      <SurfaceCard>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>預備設定</Text>
        <Text style={[styles.cardDescription, { color: colors.muted }]}>這些值會安全保留在裝置上，以供未來原生懸浮模組整合時使用。</Text>
        <View style={styles.choiceRow}>
          {(["small", "medium", "large"] as const).map((size) => (
            <Pressable key={size} onPress={() => updateSettings({ floatingWidgetSize: size })} style={({ pressed }) => [styles.choice, { borderColor: settings.floatingWidgetSize === size ? colors.primary : colors.border, backgroundColor: settings.floatingWidgetSize === size ? `${String(colors.primary)}16` : colors.background }, pressed && styles.pressed]}>
              <Text style={[styles.choiceLabel, { color: settings.floatingWidgetSize === size ? colors.primary : colors.foreground }]}>{size === "small" ? "小" : size === "medium" ? "中" : "大"}</Text>
            </Pressable>
          ))}
        </View>
      </SurfaceCard>
    </View>
  );
}

const styles = StyleSheet.create({
  stack: { gap: 12 },
  input: { height: 46, borderWidth: 1, borderRadius: 14, paddingHorizontal: 13, fontSize: 15, lineHeight: 20 },
  listCard: { paddingVertical: 2 },
  shortcutRow: { minHeight: 58, flexDirection: "row", alignItems: "center", gap: 11, borderBottomWidth: StyleSheet.hairlineWidth },
  shortcutIcon: { width: 36, height: 36, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  shortcutTitle: { flex: 1, fontSize: 15, lineHeight: 21, fontWeight: "700" },
  emptyText: { textAlign: "center", paddingVertical: 18, fontSize: 13, lineHeight: 19 },
  placeholderTitle: { color: "#142033", fontSize: 16, lineHeight: 22, fontWeight: "800", marginBottom: 4 },
  placeholderDescription: { color: "#5E6B7E", fontSize: 13, lineHeight: 19 },
  toolLabel: { fontSize: 12, lineHeight: 17, fontWeight: "800", marginBottom: 7 },
  searchRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  searchInput: { flex: 1, height: 45, borderRadius: 13, borderWidth: 1, paddingHorizontal: 11, fontSize: 15, lineHeight: 20 },
  cardHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", gap: 12, marginBottom: 6 },
  cardTitle: { fontSize: 16, lineHeight: 22, fontWeight: "800" },
  cardDescription: { fontSize: 13, lineHeight: 19, marginTop: 2, maxWidth: 240 },
  choiceRow: { flexDirection: "row", gap: 8, marginTop: 9 },
  choice: { flex: 1, minHeight: 42, borderRadius: 12, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  choiceLabel: { fontSize: 14, lineHeight: 19, fontWeight: "800" },
  pressed: { opacity: 0.76, transform: [{ scale: 0.98 }] },
});

import * as Device from "expo-device";
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

import { KeyValueRow, SurfaceCard } from "@/components/assistant-ui";
import { useAssistantData } from "@/lib/assistant-data";
import { useThemeContext, type ThemePreference } from "@/lib/theme-provider";
import { useColors } from "@/hooks/use-colors";

const themeOptions: { value: ThemePreference; label: string; icon: "white-balance-sunny" | "moon-waning-crescent" | "theme-light-dark" }[] = [
  { value: "light", label: "淺色", icon: "white-balance-sunny" },
  { value: "dark", label: "深色", icon: "moon-waning-crescent" },
  { value: "system", label: "系統", icon: "theme-light-dark" },
];

export function ProfileScreen() {
  const colors = useColors();
  const { settings, updateSettings, clearLocalData } = useAssistantData();
  const { themePreference, setThemePreference } = useThemeContext();

  const confirmClearData = () => {
    Alert.alert(
      "清除本機資料？",
      "這會刪除本 App 儲存的偏好設定、收藏聯絡人、SOS 設定、剪貼內容、語音備忘錄中繼資料與專注紀錄，不會刪除 Android 系統資料或裝置聯絡人。",
      [
        { text: "取消", style: "cancel" },
        {
          text: "確認清除",
          style: "destructive",
          onPress: () => {
            clearLocalData()
              .then(() => Alert.alert("已清除", "本 App 的本機資料已清除。"))
              .catch(() => Alert.alert("目前無法清除", "請稍後再試。"));
          },
        },
      ],
    );
  };

  return (
    <View style={styles.stack}>
      <SurfaceCard style={styles.profileCard}>
        <View style={[styles.avatar, { backgroundColor: colors.primary }]}>
          <Text style={styles.avatarText}>{settings.profileName.trim().slice(0, 1) || "你"}</Text>
        </View>
        <View style={styles.profileCopy}>
          <Text style={[styles.profileTitle, { color: colors.foreground }]}>{settings.profileName.trim() || "我的智慧小幫手"}</Text>
          <Text style={[styles.profileSubtitle, { color: colors.muted }]}>本機資料優先，依功能個別請求權限</Text>
        </View>
      </SurfaceCard>

      <SurfaceCard>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>個人化</Text>
        <Text style={[styles.fieldLabel, { color: colors.muted }]}>顯示名稱</Text>
        <TextInput
          value={settings.profileName}
          onChangeText={(profileName) => updateSettings({ profileName: profileName.slice(0, 24) })}
          placeholder="例如：小安"
          placeholderTextColor={colors.muted}
          maxLength={24}
          returnKeyType="done"
          style={[styles.input, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background }]}
        />
      </SurfaceCard>

      <SurfaceCard>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>外觀模式</Text>
        <Text style={[styles.cardDescription, { color: colors.muted }]}>選擇後立即套用，並會保留至下次開啟。</Text>
        <View style={styles.themeRow}>
          {themeOptions.map((option) => {
            const selected = themePreference === option.value;
            return (
              <Pressable
                key={option.value}
                accessibilityRole="button"
                accessibilityState={{ selected }}
                onPress={() => setThemePreference(option.value)}
                style={({ pressed }) => [
                  styles.themeOption,
                  { borderColor: selected ? colors.primary : colors.border, backgroundColor: selected ? `${String(colors.primary)}16` : colors.background },
                  pressed && styles.pressed,
                ]}
              >
                <Text style={[styles.themeOptionLabel, { color: selected ? colors.primary : colors.foreground }]}>{option.label}</Text>
              </Pressable>
            );
          })}
        </View>
      </SurfaceCard>

      <SurfaceCard>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>這台裝置</Text>
        <KeyValueRow label="品牌" value={Device.brand ?? "此裝置不提供"} icon="tag-outline" />
        <KeyValueRow label="型號" value={Device.modelName ?? "此裝置不提供"} icon="cellphone" />
        <KeyValueRow label="裝置名稱" value={Device.deviceName ?? "此裝置不提供"} icon="rename-box" />
      </SurfaceCard>

      <Pressable
        accessibilityRole="button"
        onPress={confirmClearData}
        style={({ pressed }) => [styles.dangerButton, { borderColor: colors.error, backgroundColor: `${String(colors.error)}12` }, pressed && styles.pressed]}
      >
        <Text style={[styles.dangerButtonLabel, { color: colors.error }]}>清除本機資料</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  stack: { gap: 12 },
  profileCard: { flexDirection: "row", alignItems: "center", gap: 13 },
  avatar: { width: 51, height: 51, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  avatarText: { color: "#FFFFFF", fontSize: 22, lineHeight: 27, fontWeight: "800" },
  profileCopy: { flex: 1 },
  profileTitle: { fontSize: 17, lineHeight: 23, fontWeight: "800" },
  profileSubtitle: { fontSize: 13, lineHeight: 19, marginTop: 2 },
  cardTitle: { fontSize: 16, lineHeight: 22, fontWeight: "800", marginBottom: 5 },
  cardDescription: { fontSize: 13, lineHeight: 19, marginBottom: 12 },
  fieldLabel: { fontSize: 12, lineHeight: 17, fontWeight: "700", marginTop: 7, marginBottom: 6 },
  input: { height: 45, borderWidth: 1, borderRadius: 13, paddingHorizontal: 12, fontSize: 15, lineHeight: 20 },
  themeRow: { flexDirection: "row", gap: 8, marginTop: 3 },
  themeOption: { flex: 1, minHeight: 44, borderRadius: 13, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  themeOptionLabel: { fontSize: 13, lineHeight: 18, fontWeight: "800" },
  dangerButton: { minHeight: 48, borderRadius: 16, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  dangerButtonLabel: { fontSize: 14, lineHeight: 20, fontWeight: "800" },
  pressed: { opacity: 0.76, transform: [{ scale: 0.98 }] },
});

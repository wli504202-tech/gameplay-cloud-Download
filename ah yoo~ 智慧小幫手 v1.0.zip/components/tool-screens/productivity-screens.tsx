import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import * as Brightness from "expo-brightness";
import * as Clipboard from "expo-clipboard";
import * as Contacts from "expo-contacts";
import * as FileSystem from "expo-file-system/legacy";
import * as Location from "expo-location";
import * as Sharing from "expo-sharing";
import * as SMS from "expo-sms";
import { RecordingPresets, requestRecordingPermissionsAsync, setAudioModeAsync, useAudioPlayer, useAudioPlayerStatus, useAudioRecorder, useAudioRecorderState } from "expo-audio";
import { useEffect, useMemo, useState } from "react";
import { Alert, Pressable, Share, StyleSheet, Switch, Text, TextInput, Vibration, View } from "react-native";

import { CompactButton, EmptyState, KeyValueRow, StatusCard, SurfaceCard } from "@/components/assistant-ui";
import { type VoiceNote, useAssistantData } from "@/lib/assistant-data";
import { useColors } from "@/hooks/use-colors";

// Metro bundles this local audio asset; the inline suppression is only for the untyped media module.
// eslint-disable-next-line @typescript-eslint/no-require-imports
const feedbackLoop = require("../../assets/audio/001.ogg");

const mystery = {
  title: "天空為什麼是藍色的？",
  body: "陽光進入大氣層後，短波長的藍光比紅光更容易被空氣分子向各個方向散射，因此白天從各方向看向天空時，會看見較多的藍色光。",
  question: "傍晚時天空為什麼常呈橘紅色？",
  answer: "傍晚的陽光需要穿過更長的大氣路徑，藍光多已被散射，剩下較多的紅、橘色光抵達眼睛。",
};

function uuid(prefix: string) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function formatDuration(totalSeconds: number) {
  const minutes = Math.floor(totalSeconds / 60).toString().padStart(2, "0");
  const seconds = Math.max(0, totalSeconds % 60).toString().padStart(2, "0");
  return `${minutes}:${seconds}`;
}

export function FeedbackScreen() {
  const colors = useColors();
  const { settings, updateSettings } = useAssistantData();
  const feedbackPlayer = useAudioPlayer(feedbackLoop);
  const [category, setCategory] = useState("建議");
  const [message, setMessage] = useState("");
  const categories = ["意見", "Bug 回報", "建議", "功能需求"];
  useEffect(() => {
    feedbackPlayer.loop = true;
    feedbackPlayer.volume = settings.feedbackVolume;
    if (settings.feedbackAudioEnabled) feedbackPlayer.play();
    else feedbackPlayer.pause();
    return () => feedbackPlayer.pause();
  }, [feedbackPlayer, settings.feedbackAudioEnabled, settings.feedbackVolume]);
  const submit = async () => {
    if (!message.trim()) {
      Alert.alert("請輸入內容", "請先寫下要回饋的內容。" );
      return;
    }
    try {
      await Share.share({ title: "16 宮格智慧手機小幫手回饋", message: `[${category}]\n${message.trim()}` });
      setMessage("");
    } catch {
      Alert.alert("目前無法提交", "無法開啟系統分享面板，請稍後再試。" );
    }
  };
  return (
    <View style={styles.stack}>
      <SurfaceCard>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>想和我們說什麼？</Text>
        <Text style={[styles.cardDescription, { color: colors.muted }]}>透過系統分享面板提交，不會在背景自行上傳內容。</Text>
        <View style={styles.categoryRow}>
          {categories.map((item) => (
            <Pressable key={item} onPress={() => setCategory(item)} style={({ pressed }) => [styles.category, { borderColor: category === item ? colors.primary : colors.border, backgroundColor: category === item ? `${String(colors.primary)}16` : colors.background }, pressed && styles.pressed]}>
              <Text style={[styles.categoryLabel, { color: category === item ? colors.primary : colors.foreground }]}>{item}</Text>
            </Pressable>
          ))}
        </View>
        <TextInput value={message} onChangeText={setMessage} placeholder="請輸入你的回饋…" placeholderTextColor={colors.muted} multiline textAlignVertical="top" style={[styles.feedbackInput, { color: colors.foreground, backgroundColor: colors.background, borderColor: colors.border }]} />
        <CompactButton label="開啟分享並提交" onPress={submit} icon="send-outline" />
      </SurfaceCard>
      <SurfaceCard style={styles.settingRow}>
        <View style={styles.settingCopy}>
          <Text style={[styles.settingTitle, { color: colors.foreground }]}>回饋背景音</Text>
          <Text style={[styles.settingDescription, { color: colors.muted }]}>若 `001.ogg` 未隨 App 提供，將保持靜音且不會導致程式中斷。</Text>
        </View>
        <View style={styles.volumeRow}>
          <Text style={[styles.volumeLabel, { color: colors.muted }]}>音量 {Math.round(settings.feedbackVolume * 100)}%</Text>
          <Pressable accessibilityRole="button" onPress={() => updateSettings({ feedbackVolume: Math.max(0, Number((settings.feedbackVolume - 0.1).toFixed(2))) })} style={({ pressed }) => [styles.volumeButton, { borderColor: colors.border }, pressed && styles.pressed]}><Text style={[styles.volumeButtonLabel, { color: colors.foreground }]}>−</Text></Pressable>
          <Pressable accessibilityRole="button" onPress={() => updateSettings({ feedbackVolume: Math.min(1, Number((settings.feedbackVolume + 0.1).toFixed(2))) })} style={({ pressed }) => [styles.volumeButton, { borderColor: colors.border }, pressed && styles.pressed]}><Text style={[styles.volumeButtonLabel, { color: colors.foreground }]}>＋</Text></Pressable>
          <Switch value={settings.feedbackAudioEnabled} onValueChange={(feedbackAudioEnabled) => updateSettings({ feedbackAudioEnabled })} trackColor={{ false: colors.border, true: colors.primary }} />
        </View>
      </SurfaceCard>
    </View>
  );
}

export function MysteryScreen() {
  const colors = useColors();
  const [showAnswer, setShowAnswer] = useState(false);
  return (
    <View style={styles.stack}>
      <SurfaceCard style={[styles.mysteryHero, { backgroundColor: `${String(colors.warning)}1A` }]}>
        <MaterialCommunityIcons name="weather-sunny" size={44} color={colors.warning} />
        <Text style={[styles.mysteryTitle, { color: colors.foreground }]}>{mystery.title}</Text>
        <Text style={[styles.mysteryBody, { color: colors.muted }]}>{mystery.body}</Text>
      </SurfaceCard>
      <SurfaceCard>
        <Text style={[styles.questionLabel, { color: colors.warning }]}>小問答</Text>
        <Text style={[styles.questionText, { color: colors.foreground }]}>{mystery.question}</Text>
        {showAnswer ? <Text style={[styles.answerText, { color: colors.muted }]}>{mystery.answer}</Text> : <CompactButton label="查看答案" onPress={() => setShowAnswer(true)} icon="lightbulb-on-outline" />}
      </SurfaceCard>
      <StatusCard icon="cloud-off-outline" title="離線也能閱讀" description="每日知識以內建內容呈現，不需將你的資料傳送到網路。" />
    </View>
  );
}

export function ClipboardScreen() {
  const colors = useColors();
  const { clipboardEntries, captureClipboardEntry, toggleClipboardPinned, removeClipboardEntry } = useAssistantData();
  const [query, setQuery] = useState("");
  const capture = async () => {
    try {
      const text = (await Clipboard.getStringAsync()).trim();
      if (!text) {
        Alert.alert("剪貼簿是空的", "尚未取得可儲存的文字內容。" );
        return;
      }
      captureClipboardEntry({ id: uuid("clip"), text, kind: /^https?:\/\//i.test(text) ? "url" : "text", createdAt: new Date().toISOString(), pinned: false });
    } catch {
      Alert.alert("目前無法使用此功能", "無法讀取剪貼簿。請確認系統允許此使用者主動操作。" );
    }
  };
  const filtered = useMemo(() => clipboardEntries.filter((entry) => entry.text.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase())).sort((first, second) => Number(second.pinned) - Number(first.pinned)), [clipboardEntries, query]);
  return (
    <View style={styles.stack}>
      <StatusCard icon="content-paste" title="只在你點選時擷取" description="不會在背景監聽或秘密收集剪貼簿內容。每筆記錄只保存在此裝置。" actionLabel="從剪貼簿擷取" onAction={capture} />
      <TextInput value={query} onChangeText={setQuery} placeholder="搜尋已儲存內容" placeholderTextColor={colors.muted} returnKeyType="done" style={[styles.textInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface }]} />
      {filtered.length === 0 ? <EmptyState icon="clipboard-text-outline" title="還沒有剪貼記錄" description="從剪貼簿主動擷取文字或網址後，內容會出現在這裡。" /> : null}
      {filtered.map((entry) => (
        <SurfaceCard key={entry.id} style={styles.clipCard}>
          <View style={styles.clipTopRow}>
            <Text style={[styles.clipKind, { color: colors.primary }]}>{entry.kind === "url" ? "網址" : "文字"}</Text>
            <View style={styles.clipActions}>
              <Pressable onPress={() => toggleClipboardPinned(entry.id)} style={({ pressed }) => [styles.smallIconButton, pressed && styles.pressed]}><MaterialCommunityIcons name={entry.pinned ? "pin" : "pin-outline"} size={19} color={entry.pinned ? colors.warning : colors.muted} /></Pressable>
              <Pressable onPress={() => Clipboard.setStringAsync(entry.text)} style={({ pressed }) => [styles.smallIconButton, pressed && styles.pressed]}><MaterialCommunityIcons name="content-copy" size={19} color={colors.primary} /></Pressable>
              <Pressable onPress={() => removeClipboardEntry(entry.id)} style={({ pressed }) => [styles.smallIconButton, pressed && styles.pressed]}><MaterialCommunityIcons name="trash-can-outline" size={19} color={colors.error} /></Pressable>
            </View>
          </View>
          <Text style={[styles.clipText, { color: colors.foreground }]} numberOfLines={3}>{entry.text}</Text>
          <Text style={[styles.clipTime, { color: colors.muted }]}>{new Date(entry.createdAt).toLocaleString()}</Text>
        </SurfaceCard>
      ))}
    </View>
  );
}

export function FocusScreen() {
  const colors = useColors();
  const { focusSessions, addFocusSession } = useAssistantData();
  const [selectedMinutes, setSelectedMinutes] = useState(25);
  const [remaining, setRemaining] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const totalToday = focusSessions.filter((session) => new Date(session.completedAt).toDateString() === new Date().toDateString()).reduce((total, session) => total + session.durationMinutes, 0);

  useEffect(() => {
    if (!running) return;
    const timer = setInterval(() => {
      setRemaining((current) => {
        if (current <= 1) {
          clearInterval(timer);
          setRunning(false);
          addFocusSession({ id: uuid("focus"), durationMinutes: selectedMinutes, completedAt: new Date().toISOString(), mode: "pomodoro" });
          Vibration.vibrate(180);
          Alert.alert("專注完成", `已完成 ${selectedMinutes} 分鐘專注。`);
          return 0;
        }
        return current - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [addFocusSession, running, selectedMinutes]);

  const chooseDuration = (minutes: number) => {
    if (running) return;
    setSelectedMinutes(minutes);
    setRemaining(minutes * 60);
  };
  const reset = () => {
    setRunning(false);
    setRemaining(selectedMinutes * 60);
  };
  return (
    <View style={styles.stack}>
      <SurfaceCard style={styles.focusCard}>
        <Text style={[styles.focusLabel, { color: colors.muted }]}>{running ? "正在專注" : "準備開始"}</Text>
        <Text style={[styles.timerValue, { color: colors.foreground }]}>{formatDuration(remaining)}</Text>
        <Text style={[styles.focusSubtitle, { color: colors.muted }]}>{selectedMinutes} 分鐘專注，完成後加入今日紀錄</Text>
        <View style={styles.durationRow}>
          {[25, 45, 60].map((minutes) => (
            <Pressable key={minutes} onPress={() => chooseDuration(minutes)} style={({ pressed }) => [styles.durationChip, { borderColor: selectedMinutes === minutes ? colors.primary : colors.border, backgroundColor: selectedMinutes === minutes ? `${String(colors.primary)}16` : colors.background }, pressed && styles.pressed]}><Text style={[styles.durationChipLabel, { color: selectedMinutes === minutes ? colors.primary : colors.foreground }]}>{minutes}m</Text></Pressable>
          ))}
        </View>
        <View style={styles.focusButtons}>
          <CompactButton label={running ? "暫停" : remaining === 0 ? "再來一輪" : "開始專注"} onPress={() => { if (remaining === 0) setRemaining(selectedMinutes * 60); setRunning((value) => !value); }} icon={running ? "pause" : "play"} />
          <Pressable onPress={reset} style={({ pressed }) => [styles.resetButton, { borderColor: colors.border }, pressed && styles.pressed]}><Text style={[styles.resetLabel, { color: colors.foreground }]}>重設</Text></Pressable>
        </View>
      </SurfaceCard>
      <SurfaceCard>
        <KeyValueRow label="今天專注" value={`${totalToday} 分鐘`} icon="calendar-today" />
        <KeyValueRow label="完成紀錄" value={`${focusSessions.length} 次`} icon="trophy-outline" />
      </SurfaceCard>
      <StatusCard icon="music-note-outline" tone="warning" title="環境聲音尚未選取" description="雨聲、海浪與白噪音需要可授權的音源檔；未加入音源前，本頁不會假裝正在播放。" />
    </View>
  );
}

export function FinderScreen() {
  const colors = useColors();
  const { settings, updateSettings } = useAssistantData();
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recorderState = useAudioRecorderState(recorder);
  const [isFinding, setIsFinding] = useState(false);

  useEffect(() => () => Vibration.cancel(), []);
  const toggleListening = async () => {
    if (recorderState.isRecording) {
      await recorder.stop();
      return;
    }
    try {
      const permission = await requestRecordingPermissionsAsync();
      if (!permission.granted) {
        Alert.alert("需要麥克風權限", "前景聆聽僅在你啟動此工具後使用麥克風；拒絕後不會錄音。" );
        return;
      }
      await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
      await recorder.prepareToRecordAsync();
      recorder.record();
    } catch {
      Alert.alert("目前無法使用此功能", "麥克風可能已被其他 App 使用，請稍後再試。" );
    }
  };
  const testFinder = () => {
    if (isFinding) {
      Vibration.cancel();
      setIsFinding(false);
    } else {
      Vibration.vibrate([0, 260, 140, 260], true);
      setIsFinding(true);
    }
  };
  return (
    <View style={styles.stack}>
      <SurfaceCard>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>喚醒口令</Text>
        <TextInput value={settings.finderPhrase} onChangeText={(finderPhrase) => updateSettings({ finderPhrase: finderPhrase.slice(0, 30) })} placeholder="例如：小助手你在哪？" placeholderTextColor={colors.muted} returnKeyType="done" style={[styles.textInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background }]} />
        <View style={styles.finderButtons}>
          <CompactButton label={recorderState.isRecording ? "停止前景聆聽" : "開始前景聆聽"} onPress={toggleListening} icon="microphone-outline" />
          <Pressable onPress={testFinder} style={({ pressed }) => [styles.resetButton, { borderColor: colors.border }, pressed && styles.pressed]}><Text style={[styles.resetLabel, { color: colors.foreground }]}>{isFinding ? "停止響應" : "測試響應"}</Text></Pressable>
        </View>
      </SurfaceCard>
      {isFinding ? <StatusCard icon="bell-ring-outline" tone="error" title="我在這裡" description="目前以重複震動測試尋找響應；再次點選即可停止。" actionLabel="停止" onAction={testFinder} /> : null}
      <StatusCard icon="shield-alert-outline" tone="warning" title="不支援永久背景監聽" description="Android 對背景麥克風與背景執行有限制。此功能只在你主動開啟頁面並點選前景聆聽時使用麥克風；未提供可靠語音辨識服務時不會誤稱已識別口令。" />
    </View>
  );
}

export function VoiceNoteScreen() {
  const colors = useColors();
  const { voiceNotes, saveVoiceNote, removeVoiceNote } = useAssistantData();
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recorderState = useAudioRecorderState(recorder);
  const player = useAudioPlayer();
  const playerStatus = useAudioPlayerStatus(player);
  const [activeNoteId, setActiveNoteId] = useState<string | null>(null);

  const start = async () => {
    try {
      const permission = await requestRecordingPermissionsAsync();
      if (!permission.granted) {
        Alert.alert("需要麥克風權限", "語音備忘錄僅在你按下開始錄音後才會使用麥克風。" );
        return;
      }
      await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
      await recorder.prepareToRecordAsync();
      recorder.record();
    } catch {
      Alert.alert("目前無法開始錄音", "請確認麥克風可用，或稍後再試。" );
    }
  };
  const finish = async () => {
    try {
      await recorder.stop();
      const source = recorder.uri;
      const documentDirectory = FileSystem.documentDirectory;
      if (!source || !documentDirectory) throw new Error("recording unavailable");
      const notesDirectory = `${documentDirectory}voice-notes`;
      await FileSystem.makeDirectoryAsync(notesDirectory, { intermediates: true });
      const id = uuid("voice");
      const destination = `${notesDirectory}/${id}.m4a`;
      await FileSystem.copyAsync({ from: source, to: destination });
      const durationSeconds = Math.max(1, Math.round(recorderState.durationMillis / 1000));
      saveVoiceNote({ id, title: `語音備忘 ${new Date().toLocaleDateString()}`, uri: destination, createdAt: new Date().toISOString(), durationSeconds, tags: [] });
    } catch {
      Alert.alert("目前無法儲存錄音", "錄音檔無法保存至此裝置。" );
    }
  };
  const play = (note: VoiceNote) => {
    try {
      if (activeNoteId === note.id && playerStatus.playing) {
        player.pause();
        return;
      }
      player.replace({ uri: note.uri });
      player.play();
      setActiveNoteId(note.id);
    } catch {
      Alert.alert("目前無法播放", "找不到錄音檔或此裝置不支援該格式。" );
    }
  };
  const deleteNote = (note: VoiceNote) => {
    Alert.alert("刪除語音備忘？", "此操作會刪除本機的錄音檔與中繼資料。", [
      { text: "取消", style: "cancel" },
      { text: "刪除", style: "destructive", onPress: () => { FileSystem.deleteAsync(note.uri, { idempotent: true }).catch(() => undefined).finally(() => removeVoiceNote(note.id)); } },
    ]);
  };
  const shareNote = async (note: VoiceNote) => {
    if (!(await Sharing.isAvailableAsync())) {
      Alert.alert("目前無法分享", "這台裝置不支援系統分享功能。" );
      return;
    }
    await Sharing.shareAsync(note.uri, { dialogTitle: note.title, mimeType: "audio/mp4" }).catch(() => Alert.alert("目前無法分享", "無法開啟系統分享面板。"));
  };
  return (
    <View style={styles.stack}>
      <SurfaceCard style={styles.recordCard}>
        <Text style={[styles.recordTime, { color: colors.foreground }]}>{formatDuration(Math.round(recorderState.durationMillis / 1000))}</Text>
        <Text style={[styles.recordStatus, { color: colors.muted }]}>{recorderState.isRecording ? "正在錄音，請隨時暫停或結束" : "按下開始後才會啟動麥克風"}</Text>
        <View style={styles.recordButtons}>
          {recorderState.isRecording ? <CompactButton label="暫停" onPress={() => recorder.pause()} icon="pause" /> : <CompactButton label="開始錄音" onPress={start} icon="microphone" />}
          <Pressable onPress={finish} disabled={!recorderState.canRecord} style={({ pressed }) => [styles.finishButton, { borderColor: colors.error, opacity: recorderState.canRecord ? 1 : 0.45 }, pressed && styles.pressed]}><Text style={[styles.finishLabel, { color: colors.error }]}>結束並儲存</Text></Pressable>
        </View>
      </SurfaceCard>
      <StatusCard icon="text-recognition" tone="warning" title="語音轉文字" description="本機容器尚未連接可信賴的裝置語音辨識服務。錄音會保留在裝置上，不會未經你同意上傳；轉寫功能目前顯示為不可用。" />
      {voiceNotes.length === 0 ? <EmptyState icon="microphone-message" title="尚無語音備忘" description="開始錄音並儲存後，語音檔會顯示於此。" /> : null}
      {voiceNotes.map((note) => (
        <SurfaceCard key={note.id} style={styles.noteCard}>
          <View style={styles.noteTitleRow}>
            <View style={styles.noteCopy}><Text style={[styles.noteTitle, { color: colors.foreground }]} numberOfLines={1}>{note.title}</Text><Text style={[styles.noteMeta, { color: colors.muted }]}>{formatDuration(note.durationSeconds)} · {new Date(note.createdAt).toLocaleString()}</Text></View>
            <Pressable onPress={() => deleteNote(note)} style={({ pressed }) => [styles.smallIconButton, pressed && styles.pressed]}><MaterialCommunityIcons name="trash-can-outline" size={19} color={colors.error} /></Pressable>
          </View>
          <View style={styles.noteActions}><CompactButton label={activeNoteId === note.id && playerStatus.playing ? "暫停播放" : "播放"} onPress={() => play(note)} icon={activeNoteId === note.id && playerStatus.playing ? "pause" : "play"} /><Pressable onPress={() => shareNote(note)} style={({ pressed }) => [styles.shareButton, { borderColor: colors.border }, pressed && styles.pressed]}><Text style={[styles.shareLabel, { color: colors.foreground }]}>分享</Text></Pressable></View>
        </SurfaceCard>
      ))}
    </View>
  );
}

export function SosScreen() {
  const colors = useColors();
  const { emergencyContact, setEmergencyContact } = useAssistantData();
  const [countdown, setCountdown] = useState<number | null>(null);
  const [status, setStatus] = useState("先設定緊急聯絡人，再啟動 SOS。" );

  // The timer intentionally captures the current emergency contact for this countdown.
  useEffect(() => {
    if (countdown == null) return;
    const timeout = setTimeout(() => {
      if (countdown > 1) setCountdown(countdown - 1);
      else {
        setCountdown(null);
        executeSos();
      }
    }, 1000);
    return () => clearTimeout(timeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [countdown]);

  const chooseContact = async () => {
    try {
      const permission = await Contacts.requestPermissionsAsync();
      if (permission.status !== "granted") {
        Alert.alert("需要聯絡人權限", "選擇 SOS 聯絡人時，App 僅會讀取你在系統選擇器選定的對象。" );
        return;
      }
      const contact = await Contacts.presentContactPickerAsync();
      const number = contact?.phoneNumbers?.[0]?.number;
      if (!contact || !number) return;
      setEmergencyContact({ id: contact.id, name: contact.name ?? "緊急聯絡人", phone: number });
      setStatus(`已設定 ${contact.name ?? "緊急聯絡人"}。`);
    } catch {
      Alert.alert("目前無法選擇聯絡人", "此裝置沒有可用的聯絡人選取功能。" );
    }
  };
  const executeSos = async () => {
    if (!emergencyContact) return;
    Vibration.vibrate([0, 450, 160, 450]);
    setStatus("正在取得位置並準備系統 SMS…");
    let locationText = "目前無法取得定位";
    try {
      const servicesEnabled = await Location.hasServicesEnabledAsync();
      if (servicesEnabled) {
        const permission = await Location.requestForegroundPermissionsAsync();
        if (permission.status === "granted") {
          const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
          locationText = `https://maps.google.com/?q=${location.coords.latitude},${location.coords.longitude}`;
        }
      }
    } catch {
      locationText = "目前無法取得定位";
    }
    try {
      const brightnessPermission = await Brightness.requestPermissionsAsync();
      if (brightnessPermission.status === "granted") await Brightness.setBrightnessAsync(1);
    } catch {
      // SOS still proceeds when brightness cannot be changed.
    }
    const message = `我正在使用 16 宮格智慧手機小幫手發出 SOS 求助。${locationText === "目前無法取得定位" ? "目前無法取得定位。" : `我的位置：${locationText}`}`;
    try {
      if (!(await SMS.isAvailableAsync())) {
        setStatus("此裝置不支援 SMS；已保留求助內容供你複製。" );
        await Clipboard.setStringAsync(message);
        return;
      }
      await SMS.sendSMSAsync([emergencyContact.phone], message);
      setStatus("已開啟系統 SMS 撰寫器；請在系統介面確認後送出。Android 不會回傳是否實際送達。" );
    } catch {
      setStatus("目前無法開啟系統 SMS，已將求助內容複製至剪貼簿。" );
      await Clipboard.setStringAsync(message).catch(() => undefined);
    }
  };
  const startCountdown = () => {
    if (!emergencyContact) {
      Alert.alert("請先設定聯絡人", "SOS 需要至少一位緊急聯絡人，且簡訊會由系統撰寫器讓你確認後送出。" );
      return;
    }
    setCountdown(3);
  };
  return (
    <View style={styles.stack}>
      <SurfaceCard>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>緊急聯絡人</Text>
        <KeyValueRow label="目前設定" value={emergencyContact ? `${emergencyContact.name} · ${emergencyContact.phone}` : "尚未設定"} icon="account-alert-outline" />
        <CompactButton label={emergencyContact ? "更換聯絡人" : "設定聯絡人"} onPress={chooseContact} icon="account-plus-outline" />
      </SurfaceCard>
      <SurfaceCard style={[styles.sosCard, { backgroundColor: `${String(colors.error)}0E`, borderColor: `${String(colors.error)}45` }]}>
        <Text style={[styles.sosCountdown, { color: colors.error }]}>{countdown == null ? "SOS" : countdown}</Text>
        <Text style={[styles.sosDescription, { color: colors.foreground }]}>{countdown == null ? status : "倒數中，仍可取消"}</Text>
        {countdown == null ? <Pressable onPress={startCountdown} style={({ pressed }) => [styles.sosButton, { backgroundColor: colors.error }, pressed && styles.pressed]}><Text style={styles.sosButtonLabel}>啟動 3 秒 SOS 倒數</Text></Pressable> : <Pressable onPress={() => { setCountdown(null); setStatus("已取消 SOS 倒數。" ); }} style={({ pressed }) => [styles.cancelSosButton, { borderColor: colors.error }, pressed && styles.pressed]}><Text style={[styles.cancelSosLabel, { color: colors.error }]}>取消</Text></Pressable>}
      </SurfaceCard>
      <StatusCard icon="message-alert-outline" tone="warning" title="所有求助訊息須由你確認" description="本 App 只會要求前景定位並開啟系統 SMS 撰寫器；不會背景自動傳送簡訊，也不會將 Android 的未知結果誤報為已送達。" />
    </View>
  );
}

const styles = StyleSheet.create({
  stack: { gap: 12 },
  cardTitle: { fontSize: 16, lineHeight: 22, fontWeight: "800", marginBottom: 4 },
  cardDescription: { fontSize: 13, lineHeight: 19, marginBottom: 11 },
  categoryRow: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginBottom: 12 },
  category: { minHeight: 34, paddingHorizontal: 10, borderRadius: 11, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  categoryLabel: { fontSize: 12, lineHeight: 17, fontWeight: "800" },
  feedbackInput: { minHeight: 135, borderWidth: 1, borderRadius: 15, padding: 12, fontSize: 15, lineHeight: 22, marginBottom: 11 },
  settingRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  settingCopy: { flex: 1 },
  settingTitle: { fontSize: 15, lineHeight: 21, fontWeight: "800" },
  settingDescription: { fontSize: 12, lineHeight: 18, marginTop: 2 },
  volumeRow: { flexDirection: "row", alignItems: "center", gap: 7, marginTop: 10 },
  volumeLabel: { flex: 1, fontSize: 12, lineHeight: 17 },
  volumeButton: { width: 29, height: 29, borderRadius: 9, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  volumeButtonLabel: { fontSize: 18, lineHeight: 21, fontWeight: "800" },
  mysteryHero: { alignItems: "center", gap: 10, paddingVertical: 24 },
  mysteryTitle: { fontSize: 21, lineHeight: 28, fontWeight: "800", textAlign: "center" },
  mysteryBody: { fontSize: 14, lineHeight: 22, textAlign: "center" },
  questionLabel: { fontSize: 12, lineHeight: 17, fontWeight: "900", marginBottom: 5 },
  questionText: { fontSize: 16, lineHeight: 23, fontWeight: "800", marginBottom: 10 },
  answerText: { fontSize: 14, lineHeight: 22 },
  textInput: { height: 46, borderWidth: 1, borderRadius: 14, paddingHorizontal: 13, fontSize: 15, lineHeight: 20 },
  clipCard: { gap: 5 },
  clipTopRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  clipKind: { fontSize: 12, lineHeight: 17, fontWeight: "900" },
  clipActions: { flexDirection: "row", alignItems: "center" },
  smallIconButton: { width: 34, height: 31, alignItems: "center", justifyContent: "center" },
  clipText: { fontSize: 14, lineHeight: 20 },
  clipTime: { fontSize: 11, lineHeight: 16 },
  focusCard: { alignItems: "center", paddingVertical: 24 },
  focusLabel: { fontSize: 13, lineHeight: 19, fontWeight: "800" },
  timerValue: { fontSize: 52, lineHeight: 62, letterSpacing: -2, fontWeight: "300", marginTop: 3 },
  focusSubtitle: { fontSize: 13, lineHeight: 19 },
  durationRow: { flexDirection: "row", gap: 8, marginTop: 18 },
  durationChip: { minWidth: 58, minHeight: 36, borderWidth: 1, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  durationChipLabel: { fontSize: 13, lineHeight: 18, fontWeight: "800" },
  focusButtons: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 17 },
  resetButton: { minHeight: 39, paddingHorizontal: 15, borderWidth: 1, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  resetLabel: { fontSize: 13, lineHeight: 18, fontWeight: "800" },
  finderButtons: { flexDirection: "row", gap: 10, alignItems: "center", marginTop: 11 },
  recordCard: { alignItems: "center", paddingVertical: 24 },
  recordTime: { fontSize: 42, lineHeight: 51, fontWeight: "300", letterSpacing: -1.5 },
  recordStatus: { fontSize: 13, lineHeight: 19, textAlign: "center", marginTop: 2 },
  recordButtons: { flexDirection: "row", gap: 10, alignItems: "center", marginTop: 16 },
  finishButton: { minHeight: 39, paddingHorizontal: 14, borderWidth: 1, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  finishLabel: { fontSize: 13, lineHeight: 18, fontWeight: "800" },
  noteCard: { gap: 10 },
  noteTitleRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  noteCopy: { flex: 1 },
  noteTitle: { fontSize: 15, lineHeight: 21, fontWeight: "800" },
  noteMeta: { fontSize: 12, lineHeight: 17, marginTop: 2 },
  noteActions: { flexDirection: "row", alignItems: "center", gap: 10 },
  shareButton: { minHeight: 39, paddingHorizontal: 14, borderRadius: 12, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  shareLabel: { fontSize: 13, lineHeight: 18, fontWeight: "800" },
  sosCard: { alignItems: "center", paddingVertical: 24, gap: 10 },
  sosCountdown: { fontSize: 52, lineHeight: 61, fontWeight: "900", letterSpacing: -1.5 },
  sosDescription: { fontSize: 14, lineHeight: 21, textAlign: "center" },
  sosButton: { minHeight: 47, paddingHorizontal: 19, borderRadius: 15, alignItems: "center", justifyContent: "center", marginTop: 2 },
  sosButtonLabel: { color: "#FFFFFF", fontSize: 14, lineHeight: 20, fontWeight: "900" },
  cancelSosButton: { minHeight: 47, minWidth: 130, paddingHorizontal: 19, borderRadius: 15, borderWidth: 1, alignItems: "center", justifyContent: "center", marginTop: 2 },
  cancelSosLabel: { fontSize: 14, lineHeight: 20, fontWeight: "900" },
  pressed: { opacity: 0.76, transform: [{ scale: 0.97 }] },
});

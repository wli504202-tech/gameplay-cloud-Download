import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import * as Contacts from "expo-contacts";
import { useRouter } from "expo-router";
import { useMemo, useState } from "react";
import { Alert, FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

import { CompactButton, EmptyState, ScreenHeading, StatusCard, SurfaceCard } from "@/components/assistant-ui";
import { ScreenContainer } from "@/components/screen-container";
import { useAssistantData } from "@/lib/assistant-data";
import { dialNumber } from "@/lib/device-actions";
import { useColors } from "@/hooks/use-colors";

type ContactWithPhone = Contacts.ExistingContact & { phoneNumbers: Contacts.PhoneNumber[] };

export function DialerRoute() {
  const router = useRouter();
  const colors = useColors();
  const { favoriteContactIds, toggleFavoriteContact } = useAssistantData();
  const [contacts, setContacts] = useState<ContactWithPhone[]>([]);
  const [query, setQuery] = useState("");
  const [permissionAsked, setPermissionAsked] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const loadContacts = async () => {
    setPermissionAsked(true);
    setIsLoading(true);
    try {
      const available = await Contacts.isAvailableAsync();
      if (!available) {
        Alert.alert("目前無法使用此功能", "此裝置不提供聯絡人功能。" );
        return;
      }
      const permission = await Contacts.requestPermissionsAsync();
      if (permission.status !== "granted") {
        Alert.alert("需要聯絡人權限", "快速撥號僅會在你同意後讀取含電話號碼的聯絡人。請於系統設定中重新授權。" );
        return;
      }
      const response = await Contacts.getContactsAsync({ fields: [Contacts.Fields.PhoneNumbers], sort: Contacts.SortTypes.UserDefault });
      const normalized = response.data
        .filter((contact): contact is ContactWithPhone => Boolean(contact.id && contact.phoneNumbers && contact.phoneNumbers.length))
        .sort((first, second) => (first.name ?? "").localeCompare(second.name ?? ""));
      setContacts(normalized);
    } catch {
      Alert.alert("目前無法使用此功能", "無法讀取聯絡人，請稍後再試。" );
    } finally {
      setIsLoading(false);
    }
  };

  const openNewContact = async () => {
    try {
      const permission = await Contacts.requestPermissionsAsync();
      if (permission.status !== "granted") {
        Alert.alert("需要聯絡人權限", "新增聯絡人前需要系統聯絡人權限。" );
        return;
      }
      await Contacts.presentFormAsync(null, null, { isNew: true, allowsEditing: true, allowsActions: true, message: "新增聯絡人" });
      await loadContacts();
    } catch {
      Alert.alert("目前無法開啟聯絡人", "此裝置未提供可用的原生聯絡人編輯器。" );
    }
  };

  const visibleContacts = useMemo(() => {
    const keyword = query.trim().toLocaleLowerCase();
    return contacts
      .filter((contact) => !keyword || (contact.name ?? "").toLocaleLowerCase().includes(keyword) || contact.phoneNumbers.some((phone) => phone.number?.includes(keyword)))
      .sort((first, second) => {
        const firstFavorite = favoriteContactIds.includes(first.id ?? "") ? 1 : 0;
        const secondFavorite = favoriteContactIds.includes(second.id ?? "") ? 1 : 0;
        return secondFavorite - firstFavorite || (first.name ?? "").localeCompare(second.name ?? "");
      });
  }, [contacts, favoriteContactIds, query]);

  return (
    <ScreenContainer className="flex-1" edges={["top", "left", "right", "bottom"]}>
      <FlatList
        data={visibleContacts}
        keyExtractor={(item) => item.id ?? item.name ?? Math.random().toString()}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <View style={styles.headerStack}>
            <ScreenHeading title="快速撥號" subtitle="聯絡人僅在同意後讀取，撥號交由系統處理。" onBack={() => router.back()} />
            {contacts.length === 0 ? (
              <StatusCard
                icon="account-lock-outline"
                tone="warning"
                title={permissionAsked ? "尚未取得聯絡人" : "需要聯絡人權限"}
                description="點選後才會要求讀取含電話號碼的聯絡人；拒絕時不會保留任何聯絡人資料。"
                actionLabel={isLoading ? "讀取中" : "允許並讀取"}
                onAction={loadContacts}
              />
            ) : null}
            <SurfaceCard>
              <View style={styles.searchHeader}>
                <TextInput value={query} onChangeText={setQuery} placeholder="搜尋姓名或電話" placeholderTextColor={colors.muted} returnKeyType="done" style={[styles.searchInput, { color: colors.foreground, backgroundColor: colors.background, borderColor: colors.border }]} />
                <CompactButton label="新增" onPress={openNewContact} icon="account-plus-outline" />
              </View>
            </SurfaceCard>
            {contacts.length > 0 ? <Text style={[styles.listTitle, { color: colors.foreground }]}>{visibleContacts.length} 位聯絡人</Text> : null}
          </View>
        }
        ListEmptyComponent={contacts.length > 0 ? <EmptyState icon="account-search-outline" title="沒有符合的聯絡人" description="請變更搜尋關鍵字，或新增新的聯絡人。" /> : null}
        renderItem={({ item }) => {
          const contactId = item.id ?? item.name ?? "";
          const favorite = favoriteContactIds.includes(contactId);
          const number = item.phoneNumbers[0]?.number ?? "";
          return (
            <SurfaceCard style={styles.contactCard}>
              <View style={[styles.contactAvatar, { backgroundColor: `${String(colors.primary)}18` }]}>
                <Text style={[styles.contactAvatarLabel, { color: colors.primary }]}>{(item.name ?? "?").slice(0, 1)}</Text>
              </View>
              <View style={styles.contactCopy}>
                <Text style={[styles.contactName, { color: colors.foreground }]} numberOfLines={1}>{item.name ?? "未命名聯絡人"}</Text>
                <Text style={[styles.contactNumber, { color: colors.muted }]} numberOfLines={1}>{number}</Text>
              </View>
              <Pressable accessibilityRole="button" accessibilityLabel="收藏聯絡人" onPress={() => toggleFavoriteContact(contactId)} style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}>
                <MaterialCommunityIcons name={favorite ? "star" : "star-outline"} size={22} color={favorite ? colors.warning : colors.muted} />
              </Pressable>
              <Pressable accessibilityRole="button" accessibilityLabel={`撥打 ${item.name ?? "聯絡人"}`} onPress={() => dialNumber(number)} style={({ pressed }) => [styles.dialButton, { backgroundColor: colors.success }, pressed && styles.pressed]}>
                <MaterialCommunityIcons name="phone" size={18} color="#FFFFFF" />
              </Pressable>
            </SurfaceCard>
          );
        }}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  listContent: { padding: 20, paddingBottom: 36, gap: 10 },
  headerStack: { gap: 12, marginBottom: 10 },
  searchHeader: { flexDirection: "row", alignItems: "center", gap: 8 },
  searchInput: { flex: 1, height: 45, borderWidth: 1, borderRadius: 13, paddingHorizontal: 11, fontSize: 15, lineHeight: 20 },
  listTitle: { fontSize: 14, lineHeight: 20, fontWeight: "800", marginTop: 1 },
  contactCard: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 11 },
  contactAvatar: { width: 41, height: 41, borderRadius: 15, justifyContent: "center", alignItems: "center" },
  contactAvatarLabel: { fontSize: 16, lineHeight: 21, fontWeight: "800" },
  contactCopy: { flex: 1 },
  contactName: { fontSize: 15, lineHeight: 21, fontWeight: "800" },
  contactNumber: { fontSize: 12, lineHeight: 17, marginTop: 1 },
  iconButton: { width: 36, height: 42, justifyContent: "center", alignItems: "center" },
  dialButton: { width: 40, height: 40, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  pressed: { opacity: 0.76, transform: [{ scale: 0.97 }] },
});

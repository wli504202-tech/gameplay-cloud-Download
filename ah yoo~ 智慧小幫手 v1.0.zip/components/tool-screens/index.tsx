import { View } from "react-native";

import { EmptyState } from "@/components/assistant-ui";
import { ProfileScreen } from "@/components/tool-screens/profile-screen";
import { ClipboardScreen, FeedbackScreen, FinderScreen, FocusScreen, MysteryScreen, SosScreen, VoiceNoteScreen } from "@/components/tool-screens/productivity-screens";
import { CleanerScreen, DeviceInfoScreen, FloatingWidgetScreen, LauncherScreen, NetworkScreen, QuickActionsScreen, UsageScreen } from "@/components/tool-screens/system-screens";
import type { FeatureId } from "@/lib/feature-catalog";

export function ToolScreenContent({ id }: { id: FeatureId }) {
  switch (id) {
    case "profile": return <ProfileScreen />;
    case "launcher": return <LauncherScreen />;
    case "usage": return <UsageScreen />;
    case "quick-actions": return <QuickActionsScreen />;
    case "network": return <NetworkScreen />;
    case "device": return <DeviceInfoScreen />;
    case "cleaner": return <CleanerScreen />;
    case "floating": return <FloatingWidgetScreen />;
    case "feedback": return <FeedbackScreen />;
    case "finder": return <FinderScreen />;
    case "voice-note": return <VoiceNoteScreen />;
    case "sos": return <SosScreen />;
    case "mystery": return <MysteryScreen />;
    case "clipboard": return <ClipboardScreen />;
    case "focus": return <FocusScreen />;
    default:
      return (
        <View>
          <EmptyState icon="progress-wrench" title="正在完成此工具" description="此功能的安全整合控制項正在載入。" />
        </View>
      );
  }
}

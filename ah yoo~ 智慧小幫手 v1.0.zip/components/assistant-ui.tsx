import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import type { ComponentProps, ReactNode } from "react";
import { Pressable, StyleSheet, Text, View, type StyleProp, type ViewStyle } from "react-native";

import { useColors } from "@/hooks/use-colors";

type IconName = ComponentProps<typeof MaterialCommunityIcons>["name"];

export function ScreenHeading({
  title,
  subtitle,
  onBack,
}: {
  title: string;
  subtitle?: string;
  onBack?: () => void;
}) {
  const colors = useColors();
  return (
    <View style={styles.headingRow}>
      {onBack ? (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="返回首頁"
          onPress={onBack}
          style={({ pressed }) => [styles.backButton, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && styles.pressed]}
        >
          <MaterialCommunityIcons name="arrow-left" size={22} color={colors.foreground} />
        </Pressable>
      ) : null}
      <View style={styles.headingCopy}>
        <Text style={[styles.headingTitle, { color: colors.foreground }]}>{title}</Text>
        {subtitle ? <Text style={[styles.headingSubtitle, { color: colors.muted }]}>{subtitle}</Text> : null}
      </View>
    </View>
  );
}

export function SurfaceCard({ children, style }: { children: ReactNode; style?: StyleProp<ViewStyle> }) {
  const colors = useColors();
  return <View style={[styles.surface, { backgroundColor: colors.surface, borderColor: colors.border }, style]}>{children}</View>;
}

export function StatusCard({
  icon,
  tone = "primary",
  title,
  description,
  actionLabel,
  onAction,
}: {
  icon: IconName;
  tone?: "primary" | "warning" | "error" | "success";
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  const colors = useColors();
  const color = colors[tone];
  return (
    <SurfaceCard style={styles.statusCard}>
      <View style={[styles.statusIcon, { backgroundColor: `${String(color)}18` }]}>
        <MaterialCommunityIcons name={icon} color={color} size={23} />
      </View>
      <View style={styles.statusContent}>
        <Text style={[styles.statusTitle, { color: colors.foreground }]}>{title}</Text>
        <Text style={[styles.statusDescription, { color: colors.muted }]}>{description}</Text>
        {actionLabel && onAction ? <CompactButton label={actionLabel} onPress={onAction} tone={tone} /> : null}
      </View>
    </SurfaceCard>
  );
}

export function CompactButton({
  label,
  onPress,
  tone = "primary",
  icon,
}: {
  label: string;
  onPress: () => void;
  tone?: "primary" | "warning" | "error" | "success";
  icon?: IconName;
}) {
  const colors = useColors();
  const color = colors[tone];
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [styles.compactButton, { backgroundColor: color }, pressed && styles.pressed]}
    >
      {icon ? <MaterialCommunityIcons name={icon} size={16} color="#FFFFFF" /> : null}
      <Text style={styles.compactButtonLabel}>{label}</Text>
    </Pressable>
  );
}

export function KeyValueRow({ label, value, icon }: { label: string; value: string; icon?: IconName }) {
  const colors = useColors();
  return (
    <View style={[styles.keyValueRow, { borderBottomColor: colors.border }]}>
      <View style={styles.keyLabelWrap}>
        {icon ? <MaterialCommunityIcons name={icon} size={18} color={colors.muted} /> : null}
        <Text style={[styles.keyLabel, { color: colors.muted }]}>{label}</Text>
      </View>
      <Text style={[styles.keyValue, { color: colors.foreground }]} numberOfLines={1}>{value}</Text>
    </View>
  );
}

export function EmptyState({ icon, title, description }: { icon: IconName; title: string; description: string }) {
  const colors = useColors();
  return (
    <View style={[styles.emptyState, { borderColor: colors.border, backgroundColor: colors.surface }]}>
      <MaterialCommunityIcons name={icon} size={28} color={colors.muted} />
      <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.emptyDescription, { color: colors.muted }]}>{description}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  headingRow: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 18 },
  backButton: { width: 42, height: 42, borderRadius: 15, alignItems: "center", justifyContent: "center", borderWidth: 1 },
  headingCopy: { flex: 1 },
  headingTitle: { fontSize: 25, lineHeight: 32, fontWeight: "800", letterSpacing: -0.5 },
  headingSubtitle: { fontSize: 13, lineHeight: 19, marginTop: 1 },
  surface: { borderRadius: 20, borderWidth: 1, padding: 16, shadowColor: "#142033", shadowOpacity: 0.04, shadowRadius: 16, shadowOffset: { width: 0, height: 4 }, elevation: 1 },
  statusCard: { flexDirection: "row", gap: 13, alignItems: "flex-start" },
  statusIcon: { width: 44, height: 44, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  statusContent: { flex: 1, gap: 4 },
  statusTitle: { fontSize: 16, lineHeight: 22, fontWeight: "700" },
  statusDescription: { fontSize: 13, lineHeight: 19 },
  compactButton: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 6, marginTop: 7, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 9 },
  compactButtonLabel: { color: "#FFFFFF", fontSize: 13, lineHeight: 17, fontWeight: "700" },
  keyValueRow: { minHeight: 48, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12, borderBottomWidth: StyleSheet.hairlineWidth },
  keyLabelWrap: { flexDirection: "row", alignItems: "center", gap: 8, flex: 1 },
  keyLabel: { fontSize: 14, lineHeight: 20 },
  keyValue: { fontSize: 14, lineHeight: 20, fontWeight: "700", maxWidth: "52%", textAlign: "right" },
  emptyState: { borderRadius: 20, borderWidth: 1, padding: 26, alignItems: "center", gap: 8 },
  emptyTitle: { fontSize: 16, lineHeight: 22, fontWeight: "700", textAlign: "center" },
  emptyDescription: { fontSize: 13, lineHeight: 19, textAlign: "center", maxWidth: 280 },
  pressed: { opacity: 0.78, transform: [{ scale: 0.97 }] },
});

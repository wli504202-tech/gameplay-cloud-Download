import { describe, expect, it } from "vitest";

describe("optional local-first integration setting", () => {
  it("can reach the lightweight health endpoint with the configured setting", async () => {
    const setting = process.env.SIXTEEN_GRID_UNUSED_OPTIONAL_SETTING ?? "";
    expect(setting).toBe("disabled");

    const response = await fetch("http://127.0.0.1:3000/api/health", {
      headers: { "x-sixteen-grid-optional-setting": setting },
    });
    expect(response.ok).toBe(true);
    await expect(response.json()).resolves.toMatchObject({ ok: true });
  });
});

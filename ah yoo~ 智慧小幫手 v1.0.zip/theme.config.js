/** @type {const} */
const themeColors = {
  primary: { light: '#1565D8', dark: '#8AB4FF' },
  background: { light: '#F7F9FC', dark: '#101318' },
  surface: { light: '#FFFFFF', dark: '#1A1F27' },
  foreground: { light: '#142033', dark: '#F2F5FA' },
  muted: { light: '#5E6B7E', dark: '#B7C0CF' },
  border: { light: '#D9E1EC', dark: '#313A48' },
  success: { light: '#11A683', dark: '#54D7B3' },
  warning: { light: '#F4A340', dark: '#FFC46B' },
  error: { light: '#D94A57', dark: '#FF8E99' },
};

module.exports = { themeColors };

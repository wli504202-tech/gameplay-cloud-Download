import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { useRouter } from "expo-router";
import { useMemo } from "react";
import { FlatList, Pressable, StyleSheet, Text, View, useWindowDimensions } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useAssistantData } from "@/lib/assistant-data";
import { features, type FeatureDefinition } from "@/lib/feature-catalog";
import { useThemeContext } from "@/lib/theme-provider";
import { useColors } from "@/hooks/use-colors";

const GRID_COLUMNS = 4;
const GRID_GAP = 8;
const SCREEN_PADDING = 18;

export default function HomeScreen() {
  const router = useRouter();
  const { width } = useWindowDimensions();
  const colors = useColors();
  const { themePreference } = useThemeContext();
  const { settings, focusSessions } = useAssistantData();
  const cardWidth = useMemo(
    () => Math.floor((width - SCREEN_PADDING * 2 - GRID_GAP * (GRID_COLUMNS - 1)) / GRID_COLUMNS),
    [width],
  );
  const greeting = settings.profileName ? `早安，${settings.profileName}` : "早安，這是你的工具中心";
  const focusMinutes = focusSessions.reduce((total, session) => total + session.durationMinutes, 0);

  const openFeature = (item: FeatureDefinition) => {
    router.push(`/tool/${item.id}` as never);
  };

  return (
    <ScreenContainer className="flex-1" edges={["top", "left", "right"]}>
      <FlatList
        data={features}
        numColumns={GRID_COLUMNS}
        key="four-column-grid"
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        columnWrapperStyle={styles.column}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <View>
            <View style={styles.topRow}>
              <View style={styles.brandBlock}>
                <View style={[styles.brandMark, { backgroundColor: colors.primary }]}>
                  <Text style={styles.brandMarkText}>16</Text>
                </View>
                <View>
                  <Text style={[styles.appName, { color: colors.foreground }]}>智慧小幫手</Text>
                  <Text style={[styles.appSubtitle, { color: colors.muted }]}>你的日常控制中心</Text>
                </View>
              </View>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="開啟個人檔案與設定"
                onPress={() => router.push("/tool/profile" as never)}
                style={({ pressed }) => [styles.profileButton, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && styles.pressed]}
              >
                <MaterialCommunityIcons name="account-circle-outline" size={25} color={colors.primary} />
              </Pressable>
            </View>

            <View style={[styles.heroCard, { backgroundColor: colors.primary }]}>
              <View style={styles.heroCopy}>
                <Text style={styles.heroEyebrow}>16 個實用工具</Text>
                <Text style={styles.heroTitle}>{greeting}</Text>
                <Text style={styles.heroDescription}>依需求使用功能，再決定是否授權；你的資料預設留在裝置上。</Text>
              </View>
              <View style={styles.heroBadge}>
                <MaterialCommunityIcons name="shield-check-outline" size={23} color="#FFFFFF" />
              </View>
            </View>

            <View style={styles.summaryRow}>
              <View style={[styles.summaryCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <MaterialCommunityIcons name="clock-outline" size={19} color={colors.success} />
                <View>
                  <Text style={[styles.summaryValue, { color: colors.foreground }]}>{focusMinutes > 0 ? `${focusMinutes} 分` : "尚未開始"}</Text>
                  <Text style={[styles.summaryLabel, { color: colors.muted }]}>今日專注</Text>
                </View>
              </View>
              <View style={[styles.summaryCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <MaterialCommunityIcons name="theme-light-dark" size={19} color={colors.warning} />
                <View>
                  <Text style={[styles.summaryValue, { color: colors.foreground }]}>{themePreference === "system" ? "跟隨系統" : themePreference === "dark" ? "深色" : "淺色"}</Text>
                  <Text style={[styles.summaryLabel, { color: colors.muted }]}>外觀模式</Text>
                </View>
              </View>
            </View>

            <View style={styles.sectionHeading}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>全部工具</Text>
              <Text style={[styles.sectionMeta, { color: colors.muted }]}>4 × 4</Text>
            </View>
          </View>
        }
        renderItem={({ item }) => (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={`開啟${item.title}`}
            onPress={() => openFeature(item)}
            style={({ pressed }) => [
              styles.toolCard,
              { width: cardWidth, backgroundColor: colors.surface, borderColor: colors.border },
              pressed && styles.pressed,
            ]}
          >
            <View style={[styles.toolIcon, { backgroundColor: item.softTint }]}>
              <MaterialCommunityIcons name={item.icon} size={22} color={item.tint} />
            </View>
            <Text style={[styles.toolTitle, { color: colors.foreground }]} numberOfLines={2}>{item.shortTitle}</Text>
            <Text style={[styles.toolDescription, { color: colors.muted }]} numberOfLines={1}>{item.description}</Text>
          </Pressable>
        )}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  listContent: { paddingHorizontal: SCREEN_PADDING, paddingBottom: 34 },
  column: { justifyContent: "space-between", marginBottom: GRID_GAP },
  topRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingTop: 6, marginBottom: 18 },
  brandBlock: { flexDirection: "row", alignItems: "center", gap: 10 },
  brandMark: { width: 41, height: 41, borderRadius: 15, justifyContent: "center", alignItems: "center" },
  brandMarkText: { color: "#FFFFFF", fontWeight: "900", fontSize: 16, letterSpacing: -0.7 },
  appName: { fontSize: 18, lineHeight: 23, fontWeight: "800", letterSpacing: -0.3 },
  appSubtitle: { fontSize: 12, lineHeight: 17, marginTop: 1 },
  profileButton: { width: 42, height: 42, borderRadius: 15, borderWidth: 1, justifyContent: "center", alignItems: "center" },
  heroCard: { minHeight: 140, borderRadius: 25, padding: 20, flexDirection: "row", gap: 12, overflow: "hidden", marginBottom: 12 },
  heroCopy: { flex: 1, justifyContent: "center" },
  heroEyebrow: { color: "#DCEBFF", fontSize: 12, lineHeight: 17, fontWeight: "700", marginBottom: 4 },
  heroTitle: { color: "#FFFFFF", fontSize: 20, lineHeight: 27, fontWeight: "800", letterSpacing: -0.4 },
  heroDescription: { color: "#DCEBFF", fontSize: 12, lineHeight: 18, marginTop: 6, maxWidth: 245 },
  heroBadge: { alignSelf: "flex-start", backgroundColor: "#FFFFFF2C", borderRadius: 18, width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  summaryRow: { flexDirection: "row", gap: 10, marginBottom: 20 },
  summaryCard: { flex: 1, minHeight: 62, borderRadius: 18, borderWidth: 1, flexDirection: "row", alignItems: "center", gap: 9, paddingHorizontal: 12 },
  summaryValue: { fontSize: 13, lineHeight: 18, fontWeight: "800" },
  summaryLabel: { fontSize: 11, lineHeight: 15 },
  sectionHeading: { flexDirection: "row", justifyContent: "space-between", alignItems: "baseline", marginBottom: 11 },
  sectionTitle: { fontSize: 18, lineHeight: 25, fontWeight: "800", letterSpacing: -0.2 },
  sectionMeta: { fontSize: 12, lineHeight: 17, fontWeight: "700" },
  toolCard: { height: 109, borderRadius: 18, borderWidth: 1, paddingHorizontal: 9, paddingVertical: 11, justifyContent: "space-between", shadowColor: "#142033", shadowOpacity: 0.025, shadowRadius: 8, shadowOffset: { width: 0, height: 2 }, elevation: 1 },
  toolIcon: { width: 34, height: 34, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  toolTitle: { fontSize: 12, lineHeight: 15, fontWeight: "800", letterSpacing: -0.15 },
  toolDescription: { fontSize: 9, lineHeight: 12 },
  pressed: { opacity: 0.8, transform: [{ scale: 0.97 }] },
});

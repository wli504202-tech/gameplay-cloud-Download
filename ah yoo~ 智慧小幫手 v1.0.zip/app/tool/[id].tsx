import { useLocalSearchParams, useRouter } from "expo-router";
import { ScrollView, StyleSheet, Text, View } from "react-native";

import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { ScreenHeading, SurfaceCard } from "@/components/assistant-ui";
import { ScreenContainer } from "@/components/screen-container";
import { DialerRoute } from "@/components/tool-screens/contacts-screen";
import { ToolScreenContent } from "@/components/tool-screens";
import { getFeature } from "@/lib/feature-catalog";
import { useColors } from "@/hooks/use-colors";

export default function ToolRoute() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const colors = useColors();
  const feature = getFeature(id);

  if (!feature) {
    return (
      <ScreenContainer className="p-5">
        <ScreenHeading title="找不到功能" subtitle="這個工具可能已被移除。" onBack={() => router.back()} />
      </ScreenContainer>
    );
  }

  if (feature.id === "dialer") {
    return <DialerRoute />;
  }

  return (
    <ScreenContainer className="flex-1" edges={["top", "left", "right", "bottom"]}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <ScreenHeading title={feature.title} subtitle={feature.description} onBack={() => router.back()} />
        <SurfaceCard style={styles.introCard}>
          <View style={[styles.introIcon, { backgroundColor: feature.softTint }]}>
            <MaterialCommunityIcons name={feature.icon} size={30} color={feature.tint} />
          </View>
          <Text style={[styles.introTitle, { color: colors.foreground }]}>{feature.title}</Text>
          <Text style={[styles.introDescription, { color: colors.muted }]}>{feature.description}</Text>
        </SurfaceCard>
        <ToolScreenContent id={feature.id} />
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { padding: 20, paddingBottom: 36 },
  introCard: { minHeight: 154, alignItems: "center", justifyContent: "center", gap: 9, paddingHorizontal: 24, marginBottom: 12 },
  introIcon: { width: 62, height: 62, borderRadius: 22, alignItems: "center", justifyContent: "center" },
  introTitle: { fontSize: 20, lineHeight: 27, fontWeight: "800" },
  introDescription: { fontSize: 14, lineHeight: 21, textAlign: "center" },
});
